import React, { useState, useEffect } from "react";
import { TabType, PersonalityMode } from "./types";
import { AndroidFrame } from "./components/AndroidFrame";
import { HeaderHUD } from "./components/HeaderHUD";
import { ApiKeyModal } from "./components/ApiKeyModal";
import { InstallPwaModal } from "./components/InstallPwaModal";
import { JarvisTab } from "./components/tabs/JarvisTab";
import { TaskAutomationTab } from "./components/tabs/TaskAutomationTab";
import { CodeMatrixTab } from "./components/tabs/CodeMatrixTab";
import { SearchEngineTab } from "./components/tabs/SearchEngineTab";
import { FaceScannerTab } from "./components/tabs/FaceScannerTab";
import { EmailManagerTab } from "./components/tabs/EmailManagerTab";
import { FileVaultTab } from "./components/tabs/FileVaultTab";
import { ApiMatrixTab } from "./components/tabs/ApiMatrixTab";
import { ReplicationTab } from "./components/tabs/ReplicationTab";
import { sciFiAudio } from "./utils/audio";
import { getStoredApiKey } from "./utils/apiKey";
import {
  Bot,
  ListTodo,
  Code2,
  Globe,
  Scan,
  Mail,
  Folder,
  Key,
  Server,
} from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>("jarvis");
  const [personality, setPersonality] = useState<PersonalityMode>("STARK-I");
  const [themeColor, setThemeColor] = useState<"cyan" | "magenta" | "gold" | "emerald">("cyan");
  const [activeEmotion, setActiveEmotion] = useState("Calm");
  const [isMuted, setIsMuted] = useState(false);
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [hasCustomApiKey, setHasCustomApiKey] = useState(false);

  useEffect(() => {
    setHasCustomApiKey(!!getStoredApiKey());
  }, []);

  const handleKeyUpdated = () => {
    setHasCustomApiKey(!!getStoredApiKey());
  };

  const handleTabChange = (tab: TabType) => {
    sciFiAudio.playSfx("click");
    setActiveTab(tab);
  };

  const handleToggleMute = () => {
    sciFiAudio.soundEnabled = isMuted; // toggle sound
    setIsMuted(!isMuted);
    sciFiAudio.playSfx("click");
  };

  const navItems = [
    { id: "jarvis", label: "JARVIS Core", icon: Bot },
    { id: "tasks", label: "Tasks", icon: ListTodo },
    { id: "code", label: "Code Matrix", icon: Code2 },
    { id: "search", label: "Search", icon: Globe },
    { id: "face", label: "Face Scanner", icon: Scan },
    { id: "email", label: "Email", icon: Mail },
    { id: "files", label: "File Vault", icon: Folder },
    { id: "api", label: "API Matrix", icon: Key },
    { id: "replication", label: "Replicate", icon: Server },
  ] as const;

  return (
    <AndroidFrame activeEmotion={activeEmotion} isAudioMuted={isMuted}>
      {/* Top HUD Telemetry Bar */}
      <HeaderHUD
        personality={personality}
        onPersonalityChange={setPersonality}
        themeColor={themeColor}
        onThemeChange={setThemeColor}
        activeEmotion={activeEmotion}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenApiKeyModal={() => setIsApiKeyModalOpen(true)}
        hasCustomApiKey={hasCustomApiKey}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
      />

      {/* API Key Modal Configuration Dialog */}
      <ApiKeyModal
        isOpen={isApiKeyModalOpen}
        onClose={() => setIsApiKeyModalOpen(false)}
        onKeyUpdated={handleKeyUpdated}
      />

      {/* PWA Android Install Modal */}
      <InstallPwaModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />

      {/* Center Tab View Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {activeTab === "jarvis" && (
          <JarvisTab
            personality={personality}
            activeEmotion={activeEmotion}
            themeColor={themeColor}
            onTriggerTask={(taskTitle) => setActiveTab("tasks")}
          />
        )}
        {activeTab === "tasks" && <TaskAutomationTab />}
        {activeTab === "code" && <CodeMatrixTab />}
        {activeTab === "search" && <SearchEngineTab />}
        {activeTab === "face" && (
          <FaceScannerTab onEmotionDetected={setActiveEmotion} />
        )}
        {activeTab === "email" && <EmailManagerTab />}
        {activeTab === "files" && <FileVaultTab />}
        {activeTab === "api" && (
          <ApiMatrixTab onOpenApiKeyModal={() => setIsApiKeyModalOpen(true)} />
        )}
        {activeTab === "replication" && <ReplicationTab />}
      </div>

      {/* Bottom Floating Navigation HUD Bar */}
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-[95%] max-w-4xl bg-slate-900/90 backdrop-blur-xl border border-slate-800 p-1.5 rounded-2xl shadow-2xl z-40">
        <div className="flex items-center justify-around gap-1 overflow-x-auto no-scrollbar font-mono text-[10px]">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleTabChange(item.id as TabType)}
                className={`flex flex-col items-center gap-1 px-2.5 py-1.5 rounded-xl transition-all whitespace-nowrap ${
                  isActive
                    ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.2)] font-bold scale-105"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? "text-cyan-400 animate-pulse" : ""}`} />
                <span className="hidden sm:inline">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </AndroidFrame>
  );
}
