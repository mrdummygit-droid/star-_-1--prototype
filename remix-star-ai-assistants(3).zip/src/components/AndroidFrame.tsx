import React, { useState, useEffect } from "react";
import { Wifi, BatteryCharging, Signal, Smartphone, Monitor, ShieldCheck, Zap } from "lucide-react";

interface AndroidFrameProps {
  children: React.ReactNode;
  activeEmotion?: string;
  isAudioMuted?: boolean;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  children,
  activeEmotion = "Calm",
}) => {
  const [deviceMode, setDeviceMode] = useState<"phone" | "tablet" | "fullscreen">("phone");
  const [currentTime, setCurrentTime] = useState("");
  const [batteryLevel, setBatteryLevel] = useState(98);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start p-2 sm:p-4 font-sans selection:bg-cyan-500 selection:text-slate-950 overflow-x-hidden">
      {/* Top Device View Selector Bar */}
      <div className="w-full max-w-6xl flex items-center justify-between mb-3 px-3 py-2 bg-slate-900/80 backdrop-blur-md border border-cyan-900/40 rounded-xl text-xs font-mono">
        <div className="flex items-center gap-3 text-cyan-400">
          <Zap className="w-4 h-4 text-cyan-400 animate-pulse" />
          <span className="font-semibold tracking-wider uppercase text-slate-200 hidden sm:inline">
            STAR AI ASSISTANTS • ANDROID OS 16 CONCEPT
          </span>
          <span className="bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded border border-cyan-800/60 text-[10px]">
            v3.2 NEURAL KERNEL
          </span>
        </div>

        {/* View Mode Controls */}
        <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setDeviceMode("phone")}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs transition-colors ${
              deviceMode === "phone"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-medium"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Mobile HUD</span>
          </button>
          <button
            onClick={() => setDeviceMode("tablet")}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs transition-colors ${
              deviceMode === "tablet"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-medium"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Tablet Deck</span>
          </button>
          <button
            onClick={() => setDeviceMode("fullscreen")}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs transition-colors ${
              deviceMode === "fullscreen"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-medium"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Full Workspace</span>
          </button>
        </div>
      </div>

      {/* Main Container View depending on deviceMode */}
      <div
        className={`w-full transition-all duration-300 ease-out flex justify-center ${
          deviceMode === "phone"
            ? "max-w-[440px]"
            : deviceMode === "tablet"
            ? "max-w-[900px]"
            : "max-w-7xl"
        }`}
      >
        <div
          className={`w-full bg-slate-950 relative overflow-hidden transition-all duration-300 ${
            deviceMode !== "fullscreen"
              ? "rounded-[38px] border-[10px] border-slate-900 shadow-[0_0_50px_rgba(6,182,212,0.15)] ring-1 ring-cyan-500/30"
              : "rounded-2xl border border-slate-800 shadow-2xl"
          }`}
        >
          {/* Android Phone Top Status Bar (Only shown in device mode) */}
          {deviceMode !== "fullscreen" && (
            <div className="w-full bg-slate-950 px-6 pt-3 pb-2 flex items-center justify-between text-[11px] font-mono text-slate-300 select-none z-30 relative border-b border-slate-900">
              {/* Left Clock */}
              <div className="flex items-center gap-2">
                <span className="font-semibold text-cyan-300">{currentTime || "12:00"}</span>
                <span className="text-[9px] text-cyan-500/70 bg-cyan-950/60 px-1 rounded">5G ULTRA</span>
              </div>

              {/* Center Android Punch Hole Camera reticle */}
              <div className="absolute left-1/2 top-2.5 -translate-x-1/2 flex items-center justify-center">
                <div className="w-4 h-4 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-slate-950 ring-1 ring-cyan-500/40" />
                </div>
              </div>

              {/* Right System Icons */}
              <div className="flex items-center gap-2 text-slate-400">
                <Signal className="w-3.5 h-3.5 text-cyan-400" />
                <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-bold">
                  <span>{batteryLevel}%</span>
                  <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
                </div>
              </div>
            </div>
          )}

          {/* Android App Inner Workspace */}
          <div className="w-full h-full min-h-[720px] flex flex-col bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 relative">
            {children}
          </div>

          {/* Android Bottom Navigation Pill */}
          {deviceMode !== "fullscreen" && (
            <div className="w-full bg-slate-950/90 py-2.5 flex items-center justify-center border-t border-slate-900/60 select-none">
              <div className="w-32 h-1 rounded-full bg-slate-700/80 hover:bg-cyan-400/80 transition-colors cursor-pointer" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
