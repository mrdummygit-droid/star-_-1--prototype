import React, { useState, useEffect } from "react";
import { Cpu, Activity, Shield, Volume2, VolumeX, Sparkles, User, Radio, Key, Wifi, Smartphone, Download } from "lucide-react";
import { PersonalityMode } from "../types";
import { sciFiAudio } from "../utils/audio";
import { getApiHeaders } from "../utils/apiKey";

interface HeaderHUDProps {
  personality: PersonalityMode;
  onPersonalityChange: (p: PersonalityMode) => void;
  themeColor: "cyan" | "magenta" | "gold" | "emerald";
  onThemeChange: (c: "cyan" | "magenta" | "gold" | "emerald") => void;
  activeEmotion: string;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenApiKeyModal: () => void;
  hasCustomApiKey: boolean;
  onOpenInstallModal: () => void;
}

export const HeaderHUD: React.FC<HeaderHUDProps> = ({
  personality,
  onPersonalityChange,
  themeColor,
  onThemeChange,
  activeEmotion,
  isMuted,
  onToggleMute,
  onOpenApiKeyModal,
  hasCustomApiKey,
  onOpenInstallModal,
}) => {
  const [latencyMs, setLatencyMs] = useState<number | null>(null);
  const [deviceMemory, setDeviceMemory] = useState<number>(8);
  const [cpuCores, setCpuCores] = useState<number>(8);

  useEffect(() => {
    if (typeof navigator !== "undefined") {
      if ((navigator as any).deviceMemory) {
        setDeviceMemory((navigator as any).deviceMemory);
      }
      if (navigator.hardwareConcurrency) {
        setCpuCores(navigator.hardwareConcurrency);
      }
    }

    const checkPing = async () => {
      const start = performance.now();
      try {
        const res = await fetch("/api/health", {
          headers: getApiHeaders(),
        });
        if (res.ok) {
          const end = performance.now();
          setLatencyMs(Math.round(end - start));
        }
      } catch (err) {
        setLatencyMs(null);
      }
    };

    checkPing();
    const interval = setInterval(checkPing, 10000);
    return () => clearInterval(interval);
  }, [hasCustomApiKey]);

  const getThemeTextClass = () => {
    switch (themeColor) {
      case "magenta":
        return "text-pink-400";
      case "gold":
        return "text-amber-400";
      case "emerald":
        return "text-emerald-400";
      case "cyan":
      default:
        return "text-cyan-400";
    }
  };

  const getThemeBorderClass = () => {
    switch (themeColor) {
      case "magenta":
        return "border-pink-500/40 bg-pink-950/20";
      case "gold":
        return "border-amber-500/40 bg-amber-950/20";
      case "emerald":
        return "border-emerald-500/40 bg-emerald-950/20";
      case "cyan":
      default:
        return "border-cyan-500/40 bg-cyan-950/20";
    }
  };

  return (
    <div className="w-full bg-slate-900/90 border-b border-slate-800 p-3 sm:p-4 text-xs font-mono select-none">
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Left: App Branding & Status */}
        <div className="flex items-center justify-between md:justify-start gap-3">
          <div className="flex items-center gap-2">
            <div className={`p-1.5 rounded-lg border ${getThemeBorderClass()}`}>
              <Radio className={`w-4 h-4 ${getThemeTextClass()} animate-pulse`} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm tracking-wider text-slate-100">
                  STAR AI
                </span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded border font-semibold ${getThemeBorderClass()} ${getThemeTextClass()}`}>
                  JARVIS CORE
                </span>
              </div>
              <p className="text-[10px] text-slate-400">ANDROID MULTI-AGENT ARCHITECTURE</p>
            </div>
          </div>

          {/* Emotion Badge */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1 rounded-full border border-slate-800">
            <User className="w-3 h-3 text-cyan-400" />
            <span className="text-[10px] text-slate-400 uppercase">MOOD:</span>
            <span className="text-[10px] font-bold text-cyan-300">{activeEmotion}</span>
          </div>
        </div>

        {/* Center: System Telemetry Meters (REAL DEVICE DATA) */}
        <div className="grid grid-cols-3 gap-2 bg-slate-950/90 p-2 rounded-xl border border-slate-800/80 text-[10px]">
          <div className="flex items-center gap-2">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            <div>
              <div className="text-slate-400">NPU/CPU CORES</div>
              <div className="font-bold text-slate-200">{cpuCores} LOGICAL CORES</div>
            </div>
          </div>

          <div className="flex items-center gap-2 border-l border-slate-800 pl-2">
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
            <div>
              <div className="text-slate-400">SYS MEMORY</div>
              <div className="font-bold text-slate-200">{deviceMemory} GB ALLOCATED</div>
            </div>
          </div>

          <div className="flex items-center gap-2 border-l border-slate-800 pl-2">
            <Wifi className="w-3.5 h-3.5 text-amber-400" />
            <div>
              <div className="text-slate-400">SERVER LATENCY</div>
              <div className="font-bold text-emerald-400">
                {latencyMs !== null ? `${latencyMs}ms` : "ACTIVE"}
              </div>
            </div>
          </div>
        </div>

        {/* Right: Install Android App, API Key Button, Personality Selector, Theme & Audio Controls */}
        <div className="flex items-center justify-between md:justify-end gap-2 flex-wrap sm:flex-nowrap">
          {/* Install Android PWA Button */}
          <button
            onClick={() => {
              sciFiAudio.playSfx("click");
              onOpenInstallModal();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-slate-950 font-bold rounded-lg transition-all shadow-md shadow-emerald-950/40"
            title="Install Star AI App on Android"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="text-[11px]">INSTALL APP</span>
          </button>

          {/* API Key Modal Button */}
          <button
            onClick={() => {
              sciFiAudio.playSfx("click");
              onOpenApiKeyModal();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all ${
              hasCustomApiKey
                ? "bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.2)]"
                : "bg-slate-950 border-slate-800 text-slate-300 hover:border-cyan-800 hover:text-cyan-300"
            }`}
            title="Configure Multi-Provider AI Keys (OpenRouter, Gemini, OpenAI, Claude, etc.)"
          >
            <Key className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-[11px] font-bold">API KEYS</span>
            <span
              className={`w-2 h-2 rounded-full ${
                hasCustomApiKey ? "bg-cyan-400 animate-pulse" : "bg-emerald-400"
              }`}
            />
          </button>

          {/* Personality Selector */}
          <div className="flex items-center gap-1 bg-slate-950/90 p-1 rounded-lg border border-slate-800">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 ml-1" />
            <select
              value={personality}
              onChange={(e) => {
                sciFiAudio.playSfx("click");
                onPersonalityChange(e.target.value as PersonalityMode);
              }}
              className="bg-transparent text-slate-200 text-[11px] font-mono outline-none cursor-pointer py-0.5 px-1"
            >
              <option value="STARK-I" className="bg-slate-900 text-slate-200">
                STARK-I Executive
              </option>
              <option value="CYBER-TACTICIAN" className="bg-slate-900 text-slate-200">
                Cyber Tactician
              </option>
              <option value="QUANTUM-RESEARCHER" className="bg-slate-900 text-slate-200">
                Quantum Researcher
              </option>
              <option value="CREATIVE-SYNTH" className="bg-slate-900 text-slate-200">
                Creative Synth
              </option>
            </select>
          </div>

          {/* Color Accent Picker */}
          <div className="flex items-center gap-1 bg-slate-950/90 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => {
                sciFiAudio.playSfx("click");
                onThemeChange("cyan");
              }}
              className={`w-3.5 h-3.5 rounded-full bg-cyan-400 transition-transform ${
                themeColor === "cyan" ? "scale-125 ring-2 ring-cyan-200" : "opacity-60"
              }`}
              title="Cyan Theme"
            />
            <button
              onClick={() => {
                sciFiAudio.playSfx("click");
                onThemeChange("magenta");
              }}
              className={`w-3.5 h-3.5 rounded-full bg-pink-500 transition-transform ${
                themeColor === "magenta" ? "scale-125 ring-2 ring-pink-200" : "opacity-60"
              }`}
              title="Magenta Theme"
            />
            <button
              onClick={() => {
                sciFiAudio.playSfx("click");
                onThemeChange("gold");
              }}
              className={`w-3.5 h-3.5 rounded-full bg-amber-400 transition-transform ${
                themeColor === "gold" ? "scale-125 ring-2 ring-amber-200" : "opacity-60"
              }`}
              title="Gold Theme"
            />
            <button
              onClick={() => {
                sciFiAudio.playSfx("click");
                onThemeChange("emerald");
              }}
              className={`w-3.5 h-3.5 rounded-full bg-emerald-400 transition-transform ${
                themeColor === "emerald" ? "scale-125 ring-2 ring-emerald-200" : "opacity-60"
              }`}
              title="Emerald Theme"
            />
          </div>

          {/* Audio Mute Toggle */}
          <button
            onClick={() => {
              onToggleMute();
            }}
            className={`p-1.5 rounded-lg border transition-colors ${
              isMuted
                ? "bg-rose-950/40 border-rose-800 text-rose-400"
                : "bg-slate-950 border-slate-800 text-slate-300 hover:text-cyan-400"
            }`}
            title={isMuted ? "Audio Muted" : "Audio Active"}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};

