import React, { useState, useEffect } from "react";
import { Key, CheckCircle2, AlertCircle, RefreshCw, X, ExternalLink, ShieldCheck, Trash2, Eye, EyeOff, Cpu, Sparkles, Server } from "lucide-react";
import {
  PROVIDERS,
  AIProvider,
  getActiveProvider,
  setActiveProvider,
  getProviderApiKey,
  setProviderApiKey,
  getProviderModel,
  setProviderModel,
  detectProviderFromKey,
  clearStoredApiKey,
} from "../utils/apiKey";
import { sciFiAudio } from "../utils/audio";

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onKeyUpdated: () => void;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ isOpen, onClose, onKeyUpdated }) => {
  const [selectedProvider, setSelectedProvider] = useState<AIProvider>("gemini");
  const [apiKeyInput, setApiKeyInput] = useState("");
  const [selectedModel, setSelectedModel] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifyStatus, setVerifyStatus] = useState<{
    tested: boolean;
    valid: boolean;
    message: string;
  }>({
    tested: false,
    valid: false,
    message: "",
  });

  useEffect(() => {
    if (isOpen) {
      const provider = getActiveProvider();
      setSelectedProvider(provider);
      setApiKeyInput(getProviderApiKey(provider));
      setSelectedModel(getProviderModel(provider));
      setVerifyStatus({ tested: false, valid: false, message: "" });
    }
  }, [isOpen]);

  // When changing provider tab
  const handleSelectProvider = (prov: AIProvider) => {
    sciFiAudio.playSfx("click");
    setSelectedProvider(prov);
    setApiKeyInput(getProviderApiKey(prov));
    setSelectedModel(getProviderModel(prov));
    setVerifyStatus({ tested: false, valid: false, message: "" });
  };

  // Auto-detect when key input changes
  const handleInputChange = (val: string) => {
    setApiKeyInput(val);
    const detected = detectProviderFromKey(val);
    if (detected && detected !== selectedProvider) {
      setSelectedProvider(detected);
      setSelectedModel(getProviderModel(detected));
    }
  };

  if (!isOpen) return null;

  const currentConfig = PROVIDERS[selectedProvider];

  const handleSaveAndVerify = async () => {
    const trimmed = apiKeyInput.trim();
    
    // Save state
    setActiveProvider(selectedProvider);
    setProviderApiKey(selectedProvider, trimmed);
    setProviderModel(selectedProvider, selectedModel);
    onKeyUpdated();

    sciFiAudio.playSfx("scan");
    setIsVerifying(true);
    setVerifyStatus({
      tested: false,
      valid: false,
      message: `Testing connection to ${currentConfig.name} (${selectedModel})...`,
    });

    try {
      const res = await fetch("/api/verify-key", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-provider": selectedProvider,
          "x-api-key": trimmed,
          "x-model": selectedModel,
        },
        body: JSON.stringify({
          apiKey: trimmed,
          provider: selectedProvider,
          model: selectedModel,
        }),
      });

      const data = await res.json();

      if (res.ok && data.valid) {
        sciFiAudio.playSfx("success");
        setVerifyStatus({
          tested: true,
          valid: true,
          message: data.message || `Successfully connected to ${currentConfig.name}!`,
        });
      } else {
        sciFiAudio.playSfx("chirp");
        setVerifyStatus({
          tested: true,
          valid: false,
          message: data.error || `Failed to authenticate with ${currentConfig.name}.`,
        });
      }
    } catch (err: any) {
      sciFiAudio.playSfx("chirp");
      setVerifyStatus({
        tested: true,
        valid: false,
        message: "Network error during API key verification.",
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleClearKey = () => {
    sciFiAudio.playSfx("click");
    setProviderApiKey(selectedProvider, "");
    setApiKeyInput("");
    setVerifyStatus({
      tested: true,
      valid: true,
      message: `${currentConfig.name} key cleared. Fallback active.`,
    });
    onKeyUpdated();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md font-mono select-none">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4 relative overflow-hidden">
        {/* Glow accent header */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 via-amber-400 to-purple-500" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-cyan-950/80 border border-cyan-800 rounded-xl text-cyan-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-100 tracking-wider flex items-center gap-2">
                MULTI-PROVIDER AI MATRIX
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-normal">
                  v3.5 UNIFIED
                </span>
              </h3>
              <p className="text-[10px] text-slate-400">
                CONNECT OPENROUTER, GEMINI, OPENAI, ANTHROPIC, DEEPSEEK OR GROQ
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sciFiAudio.playSfx("click");
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Provider Tabs selector */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none border-b border-slate-800/80">
          {(Object.keys(PROVIDERS) as AIProvider[]).map((pKey) => {
            const p = PROVIDERS[pKey];
            const isSelected = selectedProvider === pKey;
            const hasCustomKey = !!getProviderApiKey(pKey);

            return (
              <button
                key={pKey}
                onClick={() => handleSelectProvider(pKey)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 border ${
                  isSelected
                    ? "bg-cyan-950 text-cyan-300 border-cyan-500 shadow-md shadow-cyan-950/50"
                    : "bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200"
                }`}
              >
                <span>{p.name}</span>
                {hasCustomKey && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400" />
                )}
              </button>
            );
          })}
        </div>

        {/* Active Provider Info Banner */}
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Server className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-300 text-[11px]">PROVIDER: {currentConfig.name}</span>
          </div>
          <a
            href={currentConfig.keyHelpUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-cyan-400 hover:underline flex items-center gap-1 text-[10px] font-bold"
          >
            <span>GET API KEY</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        {/* Inputs section */}
        <div className="space-y-3">
          {/* Key input */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] text-slate-400 font-bold uppercase flex items-center justify-between">
              <span>ENTER {currentConfig.name.toUpperCase()} API KEY</span>
              <span className="text-slate-500 text-[9px]">Prefix: {currentConfig.keyPrefix}</span>
            </label>

            <div className="relative flex items-center bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 focus-within:border-cyan-500 transition-colors">
              <Key className="w-4 h-4 text-slate-500 shrink-0 mr-2" />
              <input
                type={showKey ? "text" : "password"}
                value={apiKeyInput}
                onChange={(e) => handleInputChange(e.target.value)}
                placeholder={currentConfig.placeholder}
                className="w-full bg-transparent text-xs text-slate-100 placeholder-slate-600 outline-none font-mono"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="text-slate-400 hover:text-slate-200 pl-2"
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Model selection dropdown */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] text-slate-400 font-bold uppercase flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>SELECT PREFERRED MODEL</span>
            </label>
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none focus:border-cyan-500 font-mono"
            >
              {currentConfig.models.map((m) => (
                <option key={m.id} value={m.id} className="bg-slate-900 text-slate-200">
                  {m.name} ({m.id})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Status Notification */}
        {verifyStatus.message && (
          <div
            className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 ${
              verifyStatus.tested
                ? verifyStatus.valid
                  ? "bg-emerald-950/60 border-emerald-800 text-emerald-300"
                  : "bg-rose-950/60 border-rose-800 text-rose-300"
                : "bg-cyan-950/60 border-cyan-800 text-cyan-300"
            }`}
          >
            {verifyStatus.tested ? (
              verifyStatus.valid ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              )
            ) : (
              <RefreshCw className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5 animate-spin" />
            )}
            <span className="leading-tight text-[11px]">{verifyStatus.message}</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
          {apiKeyInput && (
            <button
              onClick={handleClearKey}
              className="px-3 py-2 bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>CLEAR</span>
            </button>
          )}

          <button
            onClick={handleSaveAndVerify}
            disabled={isVerifying}
            className="flex-1 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-40 text-slate-950 font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-lg"
          >
            {isVerifying ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>VERIFYING MODEL CONNECTION...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>SAVE & TEST CONNECTION</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
