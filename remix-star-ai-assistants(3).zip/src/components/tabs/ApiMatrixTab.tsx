import React, { useState, useEffect } from "react";
import { Key, ShieldCheck, RefreshCw, Check, Zap, Server, ExternalLink, Settings, Cpu, Sparkles } from "lucide-react";
import { sciFiAudio } from "../../utils/audio";
import {
  PROVIDERS,
  AIProvider,
  getActiveProvider,
  getProviderApiKey,
  getProviderModel,
  getApiHeaders,
} from "../../utils/apiKey";

interface ApiMatrixTabProps {
  onOpenApiKeyModal?: () => void;
}

export const ApiMatrixTab: React.FC<ApiMatrixTabProps> = ({ onOpenApiKeyModal }) => {
  const [activeProv, setActiveProv] = useState<AIProvider>("gemini");
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, { status: string; latency: number }>>({});

  useEffect(() => {
    setActiveProv(getActiveProvider());
  }, []);

  const handleTestProvider = async (pKey: AIProvider) => {
    sciFiAudio.playSfx("scan");
    setTestingId(pKey);

    const key = getProviderApiKey(pKey);
    const model = getProviderModel(pKey);
    const start = performance.now();

    try {
      const res = await fetch("/api/verify-key", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-provider": pKey,
          "x-api-key": key,
          "x-model": model,
        },
        body: JSON.stringify({
          apiKey: key,
          provider: pKey,
          model,
        }),
      });

      const data = await res.json();
      const end = performance.now();
      const latency = Math.max(15, Math.round(end - start));

      if (res.ok && data.valid) {
        setTestResults((prev) => ({
          ...prev,
          [pKey]: { status: `Verified (${data.model || model})`, latency },
        }));
        sciFiAudio.playSfx("success");
      } else {
        setTestResults((prev) => ({
          ...prev,
          [pKey]: { status: data.error || "Authentication Failed", latency: 0 },
        }));
        sciFiAudio.playSfx("chirp");
      }
    } catch (err: any) {
      setTestResults((prev) => ({
        ...prev,
        [pKey]: { status: "Network/Connection Error", latency: 0 },
      }));
      sciFiAudio.playSfx("chirp");
    } finally {
      setTestingId(null);
    }
  };

  const providerKeys = Object.keys(PROVIDERS) as AIProvider[];

  return (
    <div className="flex flex-col h-full p-3 sm:p-4 gap-4 font-mono select-none">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 bg-slate-900/80 p-3 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100 text-xs tracking-wider">
            EXTERNAL AI SERVICE API MATRIX & MULTI-MODEL ROUTER
          </span>
        </div>
        <div className="flex items-center gap-2">
          {onOpenApiKeyModal && (
            <button
              onClick={() => {
                sciFiAudio.playSfx("click");
                onOpenApiKeyModal();
              }}
              className="px-2.5 py-1 bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1.5 transition-colors shadow-md"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>CONFIGURE API KEYS & PROVIDERS</span>
            </button>
          )}
        </div>
      </div>

      {/* Grid of registered providers */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {providerKeys.map((pKey) => {
          const p = PROVIDERS[pKey];
          const isActive = activeProv === pKey;
          const keyVal = getProviderApiKey(pKey);
          const currentModel = getProviderModel(pKey);
          const isTesting = testingId === pKey;
          const result = testResults[pKey];

          return (
            <div
              key={pKey}
              className={`p-4 rounded-xl border flex flex-col justify-between gap-3 transition-all ${
                isActive
                  ? "bg-cyan-950/40 border-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.15)]"
                  : "bg-slate-900/90 border-slate-800"
              }`}
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
                    {p.name}
                    {isActive && (
                      <span className="text-[9px] bg-cyan-500 text-slate-950 font-bold px-1.5 py-0.2 rounded">
                        ACTIVE ROUTE
                      </span>
                    )}
                  </span>
                  <a
                    href={p.keyHelpUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-cyan-400 hover:text-cyan-300 text-[10px] flex items-center gap-1"
                  >
                    <span>Keys</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                <div className="text-[10px] font-mono text-slate-400 space-y-0.5">
                  <div className="flex items-center justify-between">
                    <span>Selected Model:</span>
                    <span className="text-cyan-300 font-bold">{currentModel}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Key Status:</span>
                    <span className={keyVal ? "text-emerald-400 font-bold" : "text-amber-400"}>
                      {keyVal ? `${keyVal.slice(0, 8)}...` : "System / Default"}
                    </span>
                  </div>
                </div>

                {result && (
                  <div className="text-[10px] p-2 rounded bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-300 truncate">{result.status}</span>
                    {result.latency > 0 && (
                      <span className="text-emerald-400 font-bold shrink-0">{result.latency}ms</span>
                    )}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                <button
                  onClick={() => handleTestProvider(pKey)}
                  disabled={isTesting}
                  className="flex-1 py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-700 text-cyan-300 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? "animate-spin text-cyan-400" : ""}`} />
                  <span>{isTesting ? "TESTING..." : "PING TEST"}</span>
                </button>

                {onOpenApiKeyModal && (
                  <button
                    onClick={() => {
                      sciFiAudio.playSfx("click");
                      onOpenApiKeyModal();
                    }}
                    className="px-3 py-1.5 bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-cyan-300 text-xs font-bold rounded-lg transition-colors"
                  >
                    EDIT
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};


