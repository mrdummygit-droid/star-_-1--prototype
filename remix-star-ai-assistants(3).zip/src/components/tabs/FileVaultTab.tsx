import React, { useState } from "react";
import { Folder, FileText, Upload, Download, Archive, Plus, Eye, Trash2, FileCode, Check, RefreshCw } from "lucide-react";
import { FileItem } from "../../types";
import { sciFiAudio } from "../../utils/audio";

export const FileVaultTab: React.FC = () => {
  const [files, setFiles] = useState<FileItem[]>([
    {
      id: "f-1",
      name: "AndroidManifest.xml",
      size: "4.2 KB",
      type: "file",
      path: "/android/manifest",
      mimeType: "application/xml",
      modified: "Today 10:00 AM",
      content: `<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android"\n    package="com.starai.assistant">\n    <uses-permission android:name="android.permission.CAMERA" />\n    <uses-permission android:name="android.permission.RECORD_AUDIO" />\n    <uses-permission android:name="android.permission.INTERNET" />\n</manifest>`,
    },
    {
      id: "f-2",
      name: "star_assistant_core.py",
      size: "18.6 KB",
      type: "file",
      path: "/core",
      mimeType: "text/x-python",
      modified: "Today 09:30 AM",
      content: `# Star AI Assistant Python Neural Core\ndef run_diagnostics():\n    return {"status": "Nominal", "NPU_load": "14%"}`,
    },
    {
      id: "f-3",
      name: "neural_weights_v3.2.zip",
      size: "142 MB",
      type: "file",
      path: "/weights",
      mimeType: "application/zip",
      modified: "Yesterday",
    },
    {
      id: "f-4",
      name: "EdgeNodes",
      size: "Directory",
      type: "folder",
      path: "/nodes",
      mimeType: "folder",
      modified: "3 days ago",
    },
  ]);

  const [selectedFile, setSelectedFile] = useState<FileItem | null>(files[0]);
  const [newFolderName, setNewFolderName] = useState("");
  const [showFolderModal, setShowFolderModal] = useState(false);
  const [uploadNotice, setUploadNotice] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState("");

  const handleStartEdit = () => {
    if (!selectedFile || !selectedFile.content) return;
    setEditContent(selectedFile.content);
    setIsEditing(true);
    sciFiAudio.playSfx("click");
  };

  const handleSaveEdit = () => {
    if (!selectedFile) return;
    sciFiAudio.playSfx("success");
    setFiles((prev) =>
      prev.map((f) => (f.id === selectedFile.id ? { ...f, content: editContent, modified: "Just now" } : f))
    );
    setSelectedFile((prev) => (prev ? { ...prev, content: editContent, modified: "Just now" } : null));
    setIsEditing(false);
  };

  const handleCreateFolder = () => {
    if (!newFolderName.trim()) return;
    sciFiAudio.playSfx("click");
    const folder: FileItem = {
      id: `f-${Date.now()}`,
      name: newFolderName,
      size: "Directory",
      type: "folder",
      path: `/${newFolderName}`,
      mimeType: "folder",
      modified: "Just now",
    };
    setFiles((prev) => [...prev, folder]);
    setNewFolderName("");
    setShowFolderModal(false);
    sciFiAudio.playSfx("success");
  };

  const handleUploadFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;
    sciFiAudio.playSfx("activation");

    const reader = new FileReader();
    reader.onload = (event) => {
      const textContent = event.target?.result as string;
      const newFileItem: FileItem = {
        id: `f-${Date.now()}`,
        name: uploadedFile.name,
        size: `${(uploadedFile.size / 1024).toFixed(1)} KB`,
        type: "file",
        path: `/uploads/${uploadedFile.name}`,
        mimeType: uploadedFile.type || "text/plain",
        modified: "Just now",
        content: textContent || "Binary or uploaded media file.",
      };
      setFiles((prev) => [newFileItem, ...prev]);
      setSelectedFile(newFileItem);
      setUploadNotice(`File ${uploadedFile.name} uploaded successfully.`);
      sciFiAudio.playSfx("success");
      setTimeout(() => setUploadNotice(""), 3000);
    };
    reader.readAsText(uploadedFile);
  };

  const handleExtractZip = (file: FileItem) => {
    sciFiAudio.playSfx("scan");
    const extractedFolder: FileItem = {
      id: `f-${Date.now()}`,
      name: `${file.name.replace(".zip", "")}_extracted`,
      size: "Directory",
      type: "folder",
      path: `/extracted/${file.name}`,
      mimeType: "folder",
      modified: "Just now",
    };
    setFiles((prev) => [...prev, extractedFolder]);
    sciFiAudio.playSfx("success");
  };

  const handleDownloadFile = (file: FileItem) => {
    sciFiAudio.playSfx("chirp");
    const element = document.createElement("a");
    const blob = new Blob([file.content || `Star AI File Asset: ${file.name}`], {
      type: file.mimeType || "text/plain",
    });
    element.href = URL.createObjectURL(blob);
    element.download = file.name;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="flex flex-col h-full p-3 sm:p-4 gap-4 font-mono select-none">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between bg-slate-900/80 p-3 rounded-xl border border-slate-800 gap-2">
        <div className="flex items-center gap-2">
          <Folder className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100 text-xs tracking-wider">
            FILE VAULT & STORAGE MANAGER
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Create Folder Button */}
          <button
            onClick={() => setShowFolderModal(true)}
            className="px-3 py-1.5 bg-slate-950 border border-slate-800 hover:border-cyan-500 text-cyan-300 font-bold rounded-lg text-xs transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>NEW FOLDER</span>
          </button>

          {/* Upload Button */}
          <label className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center gap-1.5">
            <Upload className="w-3.5 h-3.5" />
            <span>UPLOAD FILE</span>
            <input type="file" onChange={handleUploadFile} className="hidden" />
          </label>
        </div>
      </div>

      {uploadNotice && (
        <div className="p-2.5 bg-emerald-950/60 border border-emerald-800 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{uploadNotice}</span>
        </div>
      )}

      {/* New Folder Modal */}
      {showFolderModal && (
        <div className="p-3 bg-slate-900 border border-cyan-800/80 rounded-xl flex items-center gap-2">
          <input
            type="text"
            value={newFolderName}
            onChange={(e) => setNewFolderName(e.target.value)}
            placeholder="Folder name..."
            className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1 text-xs text-slate-200 outline-none"
          />
          <button
            onClick={handleCreateFolder}
            className="px-3 py-1 bg-cyan-600 text-slate-950 font-bold rounded-lg text-xs"
          >
            CREATE
          </button>
          <button
            onClick={() => setShowFolderModal(false)}
            className="px-3 py-1 bg-slate-800 text-slate-300 rounded-lg text-xs"
          >
            CANCEL
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Left Column: File Directory Table */}
        <div className="lg:col-span-6 bg-slate-950/90 rounded-xl border border-slate-800 p-3 flex flex-col gap-2 overflow-y-auto max-h-[420px]">
          <div className="text-[10px] text-slate-400 font-bold uppercase mb-1">DIRECTORY STORAGE</div>

          <div className="flex flex-col gap-1.5">
            {files.map((file) => (
              <div
                key={file.id}
                onClick={() => setSelectedFile(file)}
                className={`p-2.5 rounded-lg border cursor-pointer transition-all flex items-center justify-between text-xs ${
                  selectedFile?.id === file.id
                    ? "bg-cyan-950/60 border-cyan-500/80 text-slate-100"
                    : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  {file.type === "folder" ? (
                    <Folder className="w-4 h-4 text-amber-400" />
                  ) : file.mimeType.includes("zip") ? (
                    <Archive className="w-4 h-4 text-pink-400" />
                  ) : (
                    <FileCode className="w-4 h-4 text-cyan-400" />
                  )}
                  <div>
                    <div className="font-bold text-slate-200">{file.name}</div>
                    <div className="text-[10px] text-slate-500">{file.size} • {file.modified}</div>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {file.mimeType.includes("zip") && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleExtractZip(file);
                      }}
                      className="p-1 bg-pink-950 border border-pink-800 text-pink-300 rounded hover:bg-pink-900"
                      title="Extract Archive"
                    >
                      <Archive className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {file.type === "file" && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDownloadFile(file);
                      }}
                      className="p-1 bg-cyan-950 border border-cyan-800 text-cyan-300 rounded hover:bg-cyan-900"
                      title="Download File"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: File Preview Panel */}
        <div className="lg:col-span-6 bg-slate-950/90 rounded-xl border border-slate-800 p-4 flex flex-col gap-3">
          {selectedFile ? (
            <>
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <h4 className="font-bold text-sm text-cyan-300">{selectedFile.name}</h4>
                  <p className="text-[10px] text-slate-400">{selectedFile.path} • {selectedFile.size}</p>
                </div>
                {selectedFile.type === "file" && (
                  <div className="flex items-center gap-2">
                    {selectedFile.content && (
                      isEditing ? (
                        <button
                          onClick={handleSaveEdit}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-lg text-xs transition-colors flex items-center gap-1"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>SAVE</span>
                        </button>
                      ) : (
                        <button
                          onClick={handleStartEdit}
                          className="px-2.5 py-1 bg-slate-900 border border-slate-800 hover:border-cyan-500 text-cyan-300 font-bold rounded-lg text-xs transition-colors flex items-center gap-1"
                        >
                          <FileCode className="w-3.5 h-3.5" />
                          <span>EDIT</span>
                        </button>
                      )
                    )}
                    <button
                      onClick={() => handleDownloadFile(selectedFile)}
                      className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-lg text-xs transition-colors flex items-center gap-1"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>DOWNLOAD</span>
                    </button>
                  </div>
                )}
              </div>

              {selectedFile.content ? (
                isEditing ? (
                  <textarea
                    value={editContent}
                    onChange={(e) => setEditContent(e.target.value)}
                    className="w-full h-[280px] bg-slate-900 p-3 rounded-xl border border-cyan-500 text-xs text-cyan-100 font-mono outline-none leading-relaxed resize-none focus:ring-1 focus:ring-cyan-400"
                  />
                ) : (
                  <pre className="bg-slate-900/90 p-3 rounded-xl border border-slate-800 text-xs text-cyan-200 overflow-y-auto max-h-[300px] leading-relaxed whitespace-pre-wrap font-mono">
                    {selectedFile.content}
                  </pre>
                )
              ) : (
                <div className="flex flex-col items-center justify-center p-8 text-center text-slate-500 gap-2 border border-slate-800/60 rounded-xl bg-slate-900/40">
                  <Archive className="w-8 h-8 text-cyan-400/40" />
                  <span className="text-xs">Archive or Binary directory asset.</span>
                </div>
              )}
            </>
          ) : (
            <div className="text-center text-slate-500 p-8">Select a file to view contents.</div>
          )}
        </div>
      </div>
    </div>
  );
};
