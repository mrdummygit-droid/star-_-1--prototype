import React, { useState } from "react";
import { Download, QrCode, Smartphone, Server, Terminal, Copy, Check, RefreshCw, Cpu, Wifi } from "lucide-react";
import { NodeDevice } from "../../types";
import { sciFiAudio } from "../../utils/audio";

export const ReplicationTab: React.FC = () => {
  const [nodes, setNodes] = useState<NodeDevice[]>([
    {
      id: "node-1",
      name: "Galaxy S24 Ultra (Primary)",
      ip: "192.168.1.104",
      deviceType: "Android Mobile",
      status: "Online",
      cpuUsage: 14,
      memoryUsage: 32,
      activeTaskCount: 2,
      lastSync: "Just now",
      location: "San Francisco, CA",
    },
    {
      id: "node-2",
      name: "Pixel Tablet Core",
      ip: "192.168.1.112",
      deviceType: "Tablet OS",
      status: "Syncing",
      cpuUsage: 45,
      memoryUsage: 58,
      activeTaskCount: 1,
      lastSync: "2 mins ago",
      location: "Home Office Node",
    },
    {
      id: "node-3",
      name: "Linux Edge Server Alpha",
      ip: "10.0.4.88",
      deviceType: "Linux Edge Node",
      status: "Online",
      cpuUsage: 8,
      memoryUsage: 18,
      activeTaskCount: 5,
      lastSync: "1 min ago",
      location: "Cloud Cluster",
    },
  ]);

  const [isDeploying, setIsDeploying] = useState(false);
  const [targetIp, setTargetIp] = useState("");
  const [targetDeviceName, setTargetDeviceName] = useState("");
  const [copiedScript, setCopiedScript] = useState(false);

  const sshReplicationScript = `curl -sSL https://star-ai.android.internal/install.sh | bash -s -- --node-key="STAR_AI_NODE_KEY_9012" --master-ip="192.168.1.104"`;

  const handleDownloadApk = () => {
    sciFiAudio.playSfx("activation");
    // Generate simulated APK package file download for user
    const apkManifest = `[Star AI Assistant v3.2 APK Bundle]\nPackage: com.starai.assistant\nBuild: 2026.08.08\nCapabilities: Voice, NPU, Camera, Task Automation`;
    const blob = new Blob([apkManifest], { type: "application/vnd.android.package-archive" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "Star_AI_Assistant_v3.2_Release.apk";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    sciFiAudio.playSfx("success");
  };

  const handleDeployToNode = () => {
    if (!targetDeviceName.trim()) return;
    sciFiAudio.playSfx("scan");
    setIsDeploying(true);

    setTimeout(() => {
      const newNode: NodeDevice = {
        id: `node-${Date.now()}`,
        name: targetDeviceName,
        ip: targetIp || "192.168.1.188",
        deviceType: "Android Mobile",
        status: "Online",
        cpuUsage: 12,
        memoryUsage: 28,
        activeTaskCount: 0,
        lastSync: "Just now",
        location: "Remote Device",
      };

      setNodes((prev) => [newNode, ...prev]);
      setTargetDeviceName("");
      setTargetIp("");
      setIsDeploying(false);
      sciFiAudio.playSfx("success");
    }, 2000);
  };

  const handleCopyScript = () => {
    navigator.clipboard.writeText(sshReplicationScript);
    setCopiedScript(true);
    sciFiAudio.playSfx("chirp");
    setTimeout(() => setCopiedScript(false), 2000);
  };

  return (
    <div className="flex flex-col h-full p-3 sm:p-4 gap-4 font-mono select-none">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-slate-900/80 p-3 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2">
          <Server className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100 text-xs tracking-wider">
            SELF-INSTALLATION & NODE REPLICATION PROTOCOL
          </span>
        </div>
        <span className="text-[10px] text-cyan-400 font-bold bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800">
          NETWORK MATRIX: {nodes.filter((n) => n.status === "Online").length} / {nodes.length} SYNCHRONIZED
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Left Column: APK Installer & QR Mobile Pairing */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          {/* APK Package Download Card */}
          <div className="bg-slate-900/90 rounded-xl p-4 border border-slate-800 flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-xs font-bold text-cyan-300">
              <span className="flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-cyan-400" /> ANDROID APK BUNDLE (v3.2)
              </span>
              <span className="text-[10px] text-emerald-400">SIGNED & VERIFIED</span>
            </div>

            <p className="text-xs text-slate-300 leading-normal">
              Download the native Star AI Assistant Android application bundle for offline side-loading on target Android mobile devices and tablets.
            </p>

            <button
              onClick={handleDownloadApk}
              className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-xl text-xs transition-all shadow-lg flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>DOWNLOAD STAR_AI_ASSISTANT_v3.2.APK</span>
            </button>
          </div>

          {/* QR Code Quick Deploy Card */}
          <div className="bg-slate-900/90 rounded-xl p-4 border border-slate-800 flex flex-col items-center text-center gap-3">
            <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
              <QrCode className="w-4 h-4" /> INSTANT MOBILE QR PAIRING
            </span>

            {/* Holographic QR Code Box */}
            <div className="p-3 bg-white rounded-xl shadow-xl flex items-center justify-center border-2 border-cyan-400">
              <div className="w-28 h-28 bg-slate-950 p-2 rounded flex flex-col justify-between items-center text-[8px] font-mono text-cyan-400">
                <div className="w-full flex justify-between">
                  <div className="w-6 h-6 border-2 border-cyan-400 bg-cyan-950" />
                  <div className="w-6 h-6 border-2 border-cyan-400 bg-cyan-950" />
                </div>
                <div className="text-center font-bold">SCAN TO REPLICATE</div>
                <div className="w-full flex justify-between">
                  <div className="w-6 h-6 border-2 border-cyan-400 bg-cyan-950" />
                  <div className="w-4 h-4 bg-cyan-400 animate-pulse" />
                </div>
              </div>
            </div>

            <span className="text-[10px] text-slate-400">
              Point target Android phone camera at QR code to auto-replicate Star AI.
            </span>
          </div>
        </div>

        {/* Right Column: Remote Node Matrix & Deploy Script */}
        <div className="lg:col-span-7 flex flex-col gap-3">
          {/* Active Nodes Grid */}
          <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-800 flex flex-col gap-2 max-h-[260px] overflow-y-auto">
            <div className="text-[10px] text-slate-400 font-bold uppercase mb-1">CONNECTED REPLICATED NODES</div>

            <div className="flex flex-col gap-2">
              {nodes.map((node) => (
                <div
                  key={node.id}
                  className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-3">
                    <Smartphone className="w-4 h-4 text-cyan-400" />
                    <div>
                      <div className="font-bold text-slate-200">{node.name}</div>
                      <div className="text-[10px] text-slate-500">
                        {node.ip} • {node.deviceType} • {node.location}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 text-right">
                    <div>
                      <div className="text-[10px] text-slate-400">CPU {node.cpuUsage}% • RAM {node.memoryUsage}%</div>
                      <div className="text-[10px] text-cyan-400 font-bold">Synced: {node.lastSync}</div>
                    </div>
                    <span
                      className={`w-2.5 h-2.5 rounded-full ${
                        node.status === "Online"
                          ? "bg-emerald-400 animate-pulse"
                          : "bg-amber-400 animate-ping"
                      }`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Trigger Remote Replication Command */}
          <div className="bg-slate-900/90 rounded-xl p-4 border border-slate-800 flex flex-col gap-3">
            <div className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
              <Terminal className="w-4 h-4" /> REPLICATE TO REMOTE IP NODE
            </div>

            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={targetDeviceName}
                onChange={(e) => setTargetDeviceName(e.target.value)}
                placeholder="Device Label (e.g. Pixel 8 Pro)"
                className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 outline-none focus:border-cyan-500"
              />

              <input
                type="text"
                value={targetIp}
                onChange={(e) => setTargetIp(e.target.value)}
                placeholder="Target IP Address..."
                className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 outline-none focus:border-cyan-500 font-mono"
              />
            </div>

            <button
              onClick={handleDeployToNode}
              disabled={!targetDeviceName.trim() || isDeploying}
              className="py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-slate-950 font-bold rounded-lg text-xs transition-all flex items-center justify-center gap-1.5"
            >
              {isDeploying ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Wifi className="w-3.5 h-3.5" />
              )}
              <span>DEPLOY & SYNCHRONIZE NODE</span>
            </button>

            {/* SSH Shell Script */}
            <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 text-[10px] text-cyan-300 font-mono flex items-center justify-between">
              <span className="truncate max-w-[280px]">{sshReplicationScript}</span>
              <button
                onClick={handleCopyScript}
                className="p-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded transition-colors"
                title="Copy Script"
              >
                {copiedScript ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
