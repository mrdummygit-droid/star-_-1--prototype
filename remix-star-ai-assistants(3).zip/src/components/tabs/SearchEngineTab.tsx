import React, { useState } from "react";
import { Search, Globe, Sparkles, ExternalLink, ShieldCheck, Bookmark, RefreshCw, Layers } from "lucide-react";
import { sciFiAudio } from "../../utils/audio";
import { getApiHeaders } from "../../utils/apiKey";

interface SearchResultData {
  summary: string;
  keyFacts: string[];
  sources: { title: string; url: string }[];
  confidenceScore: number;
}

export const SearchEngineTab: React.FC = () => {
  const [query, setQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [result, setResult] = useState<SearchResultData | null>({
    summary:
      "Star AI Assistant Search Engine utilizes orbital neural synthesis and real-time Web grounding to retrieve, index, and organize global information streams with verified precision.",
    keyFacts: [
      "Supported multi-node indexing across Google Search Grounding and neural memory.",
      "Integrated automated fact extraction and source citation links.",
      "Real-time synthesis powered by server-side Gemini AI engines.",
    ],
    sources: [
      { title: "Android AI Developers Guide", url: "https://developer.android.com/ai" },
      { title: "Google DeepMind AI Studio", url: "https://ai.google.dev" },
    ],
    confidenceScore: 98,
  });

  const handleSearch = async (searchQuery?: string) => {
    const q = (searchQuery || query).trim();
    if (!q || isSearching) return;

    sciFiAudio.playSfx("click");
    setIsSearching(true);

    try {
      const res = await fetch("/api/search-synthesize", {
        method: "POST",
        headers: getApiHeaders(),
        body: JSON.stringify({ query: q }),
      });

      const data = await res.json();
      setResult({
        summary: data.summary || "Search complete.",
        keyFacts: data.keyFacts || [],
        sources: data.sources || [],
        confidenceScore: data.confidenceScore || 95,
      });
      sciFiAudio.playSfx("success");
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="flex flex-col h-full p-3 sm:p-4 gap-4 font-mono select-none">
      {/* Search Bar Header */}
      <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col gap-3">
        <div className="flex items-center justify-between text-xs">
          <span className="flex items-center gap-2 text-cyan-400 font-bold tracking-wider">
            <Globe className="w-4 h-4 animate-spin" /> ORBITAL SEARCH ENGINE & INTELLIGENCE SYNTHESIS
          </span>
          <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
            GOOGLE SEARCH GROUNDING ACTIVE
          </span>
        </div>

        {/* Input & Button */}
        <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 focus-within:border-cyan-500 transition-colors">
          <Search className="w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            placeholder="Search global network, Android APIs, tech research, or ask Star AI..."
            className="w-full bg-transparent text-xs text-slate-200 placeholder-slate-500 outline-none font-mono"
          />
          <button
            onClick={() => handleSearch()}
            disabled={!query.trim() || isSearching}
            className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-slate-950 font-bold rounded-lg text-xs transition-all flex items-center gap-1.5"
          >
            {isSearching ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>INDEXING...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>SYNTHESIZE</span>
              </>
            )}
          </button>
        </div>

        {/* Popular Query Chips */}
        <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400 mt-1">
          <span className="text-slate-500">POPULAR:</span>
          {[
            "Android 16 AI features",
            "Multi-agent autonomous systems",
            "Gemini 3.6 Flash capabilities",
            "Quantum neural network benchmarks",
          ].map((chip, idx) => (
            <button
              key={idx}
              onClick={() => {
                setQuery(chip);
                handleSearch(chip);
              }}
              className="px-2.5 py-0.5 rounded-full bg-slate-950 hover:bg-slate-800 border border-slate-800 text-cyan-300 transition-colors"
            >
              {chip}
            </button>
          ))}
        </div>
      </div>

      {/* Results Workspace */}
      {result && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
          {/* Main Synthesis Column */}
          <div className="lg:col-span-8 bg-slate-950/90 rounded-xl border border-slate-800 p-4 flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="flex items-center gap-2 text-xs font-bold text-cyan-300">
                <Sparkles className="w-4 h-4 text-cyan-400" /> AI SYNTHESIS BRIEFING
              </span>
              <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-bold bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-900">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>CONFIDENCE SCORE: {result.confidenceScore}%</span>
              </div>
            </div>

            <p className="text-xs text-slate-200 leading-relaxed bg-slate-900/60 p-3 rounded-xl border border-slate-800/80">
              {result.summary}
            </p>

            {/* Key Facts Cards */}
            {result.keyFacts.length > 0 && (
              <div className="flex flex-col gap-2">
                <span className="text-[10px] text-slate-400 font-bold uppercase">INDEXED KEY TAKEAWAYS</span>
                <div className="grid grid-cols-1 gap-2">
                  {result.keyFacts.map((fact, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 text-xs text-slate-300 flex items-start gap-2"
                    >
                      <span className="text-cyan-400 font-bold">[{idx + 1}]</span>
                      <span>{fact}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Grounded Sources & Citations */}
          <div className="lg:col-span-4 bg-slate-950/90 rounded-xl border border-slate-800 p-4 flex flex-col gap-3">
            <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 border-b border-slate-800 pb-2">
              <Bookmark className="w-3.5 h-3.5" /> GROUNDED SOURCES & CITATIONS
            </div>

            <div className="flex flex-col gap-2 overflow-y-auto max-h-[300px]">
              {result.sources.map((src, idx) => (
                <a
                  key={idx}
                  href={src.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-slate-900 hover:bg-slate-850 rounded-xl border border-slate-800 hover:border-cyan-500/50 text-xs text-slate-200 transition-all flex items-start justify-between group"
                >
                  <div className="flex flex-col gap-0.5">
                    <span className="font-bold text-cyan-300 group-hover:text-cyan-200">{src.title}</span>
                    <span className="text-[10px] text-slate-500 truncate max-w-[200px]">{src.url}</span>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-cyan-400 opacity-60 group-hover:opacity-100 transition-opacity" />
                </a>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
