import React, { useState } from "react";
import { Mail, Send, Sparkles, Inbox, RefreshCw, Star, Tag, Check, ArrowRight } from "lucide-react";
import { EmailItem } from "../../types";
import { sciFiAudio } from "../../utils/audio";
import { getApiHeaders } from "../../utils/apiKey";

export const EmailManagerTab: React.FC = () => {
  const [emails, setEmails] = useState<EmailItem[]>([
    {
      id: "e-1",
      sender: "security@star-ai.android",
      recipient: "user@star-ai.android",
      subject: "Security Audit Report: Edge Node Authorization",
      body: "All connected edge Android devices have completed OAuth 2.0 handshake verification. Zero vulnerabilities detected.",
      timestamp: "10:30 AM",
      read: false,
      priority: "High",
      tags: ["Security", "System"],
    },
    {
      id: "e-2",
      sender: "dev-team@android.org",
      recipient: "user@star-ai.android",
      subject: "Android 16 Kernel Patch Notes v3.2",
      body: "Included direct NPU hardware bindings for Gemini 3.6 Flash models. Reduced inference latency by 35%.",
      timestamp: "09:15 AM",
      read: true,
      priority: "Normal",
      tags: ["Updates", "NPU"],
    },
  ]);

  const [selectedEmail, setSelectedEmail] = useState<EmailItem | null>(emails[0]);

  // AI Drafter state
  const [recipient, setRecipient] = useState("");
  const [subject, setSubject] = useState("");
  const [context, setContext] = useState("");
  const [tone, setTone] = useState("Executive");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedBody, setGeneratedBody] = useState("");

  const handleGenerateEmail = async () => {
    if (!context.trim() || isGenerating) return;
    sciFiAudio.playSfx("click");
    setIsGenerating(true);

    try {
      const res = await fetch("/api/email-assist", {
        method: "POST",
        headers: getApiHeaders(),
        body: JSON.stringify({
          action: "draft",
          recipient,
          subject,
          context,
          tone,
        }),
      });

      const data = await res.json();
      setSubject(data.subject || subject);
      setGeneratedBody(data.body || "Draft completed.");
      sciFiAudio.playSfx("success");
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSendEmail = () => {
    sciFiAudio.playSfx("activation");
    const newEmail: EmailItem = {
      id: `e-${Date.now()}`,
      sender: "me@star-ai.android",
      recipient: recipient || "team@star-ai.android",
      subject: subject || "Star AI Command Dispatch",
      body: generatedBody || context,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      read: true,
      priority: "High",
      tags: ["Sent", "AI Generated"],
    };

    setEmails((prev) => [newEmail, ...prev]);
    setSelectedEmail(newEmail);
    setRecipient("");
    setSubject("");
    setContext("");
    setGeneratedBody("");
    sciFiAudio.playSfx("success");
  };

  return (
    <div className="flex flex-col h-full p-3 sm:p-4 gap-4 font-mono select-none">
      {/* Top Banner */}
      <div className="flex items-center justify-between bg-slate-900/80 p-3 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2">
          <Mail className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100 text-xs tracking-wider">
            EMAIL COMMAND POST & AUTOMATED DISPATCH
          </span>
        </div>
        <span className="text-[10px] text-cyan-400 font-bold bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800">
          {emails.filter((e) => !e.read).length} UNREAD MESSAGES
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Left Column: Inbox List */}
        <div className="lg:col-span-5 bg-slate-950/90 rounded-xl border border-slate-800 p-3 flex flex-col gap-2 max-h-[450px] overflow-y-auto">
          <div className="text-[10px] text-slate-400 font-bold uppercase mb-1 flex items-center justify-between">
            <span>INBOX FEED</span>
            <Inbox className="w-3.5 h-3.5 text-slate-500" />
          </div>

          {emails.map((email) => (
            <div
              key={email.id}
              onClick={() => {
                setSelectedEmail(email);
                setEmails((prev) =>
                  prev.map((e) => (e.id === email.id ? { ...e, read: true } : e))
                );
              }}
              className={`p-3 rounded-xl border cursor-pointer transition-all flex flex-col gap-1.5 ${
                selectedEmail?.id === email.id
                  ? "bg-cyan-950/60 border-cyan-500/80 text-slate-100"
                  : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850"
              }`}
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-cyan-300 truncate max-w-[200px]">
                  {email.sender}
                </span>
                <span className="text-[10px] text-slate-500">{email.timestamp}</span>
              </div>

              <div className="text-xs font-semibold truncate text-slate-200">
                {!email.read && (
                  <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 mr-1.5" />
                )}
                {email.subject}
              </div>

              <div className="flex items-center gap-1.5 mt-0.5">
                {email.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-[9px] px-1.5 py-0.2 rounded bg-slate-950 border border-slate-800 text-slate-400"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Right Column: AI Drafter & Email Reader */}
        <div className="lg:col-span-7 flex flex-col gap-3">
          {/* Email Reader View */}
          {selectedEmail && (
            <div className="bg-slate-950/90 rounded-xl p-4 border border-slate-800 flex flex-col gap-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <h4 className="font-bold text-sm text-cyan-300">{selectedEmail.subject}</h4>
                  <p className="text-[10px] text-slate-400">
                    From: {selectedEmail.sender} • To: {selectedEmail.recipient}
                  </p>
                </div>
                <span className="text-[10px] text-slate-500">{selectedEmail.timestamp}</span>
              </div>

              <div className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3 rounded-lg border border-slate-800/80 whitespace-pre-wrap">
                {selectedEmail.body}
              </div>
            </div>
          )}

          {/* AI Email Composer */}
          <div className="bg-slate-900/90 rounded-xl p-4 border border-slate-800 flex flex-col gap-3">
            <div className="flex items-center justify-between text-xs font-bold text-cyan-400">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" /> AI EMAIL ASSISTANT & COMPOSER
              </span>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="bg-slate-950 text-slate-300 border border-slate-800 rounded px-2 py-0.5 text-[10px] outline-none"
              >
                <option value="Executive">Tone: Executive</option>
                <option value="Formal">Tone: Formal</option>
                <option value="Urgent">Tone: Urgent</option>
                <option value="Friendly">Tone: Friendly</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                placeholder="Recipient Email..."
                className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 outline-none focus:border-cyan-500"
              />

              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Subject line..."
                className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 outline-none focus:border-cyan-500"
              />
            </div>

            <textarea
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder="Enter context or bullet points for AI email generation..."
              rows={2}
              className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 outline-none focus:border-cyan-500 resize-none"
            />

            {generatedBody && (
              <div className="p-3 bg-slate-950 rounded-lg border border-cyan-800/60 text-xs text-slate-200 whitespace-pre-wrap">
                <span className="text-[10px] text-cyan-400 font-bold block mb-1">GENERATED DRAFT:</span>
                {generatedBody}
              </div>
            )}

            <div className="flex items-center gap-2">
              <button
                onClick={handleGenerateEmail}
                disabled={!context.trim() || isGenerating}
                className="flex-1 py-2 bg-slate-950 hover:bg-slate-800 border border-cyan-800 text-cyan-300 font-bold rounded-lg text-xs transition-all flex items-center justify-center gap-1.5"
              >
                {isGenerating ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                <span>DRAFT WITH AI</span>
              </button>

              <button
                onClick={handleSendEmail}
                disabled={!generatedBody && !context}
                className="flex-1 py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-lg text-xs transition-all flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>DISPATCH EMAIL</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
