import React, { useState } from "react";
import { Code2, Play, Sparkles, Terminal, Copy, Check, RefreshCw, Cpu, Layers } from "lucide-react";
import { sciFiAudio } from "../../utils/audio";
import { getApiHeaders } from "../../utils/apiKey";

export const CodeMatrixTab: React.FC = () => {
  const [language, setLanguage] = useState<"python" | "javascript" | "typescript" | "kotlin" | "cpp" | "bash">("python");
  
  const defaultSnippets: Record<string, string> = {
    python: `import sys\nimport time\n\ndef star_neural_cluster(nodes=5):\n    print("[STAR AI Python Core] Initializing Neural Cluster...")\n    for i in range(nodes):\n        time.sleep(0.1)\n        print(f"  -> Node #{i+1} online. Matrix sync rate: 99.8%")\n    return "CLUSTER_READY"\n\nif __name__ == "__main__":
    result = star_neural_cluster()\n    print(f"Status: {result}")`,
    javascript: `// Star AI Assistant JavaScript Core\nasync function executeAutomationTask(taskId) {\n  console.log(\`[Star AI JS Matrix] Running Task \${taskId}...\`);\n  const metrics = { cpu: "14%", ram: "3.2GB", status: "Nominal" };\n  return metrics;\n}\n\nexecuteAutomationTask("TASK_9012").then(console.log);`,
    typescript: `interface StarAgentConfig {\n  id: string;\n  version: string;\n  quantumMode: boolean;\n}\n\nconst agentConfig: StarAgentConfig = {\n  id: "STARK-I-ALPHA",\n  version: "v3.2.0",\n  quantumMode: true,\n};\n\nconsole.log("[TypeScript Kernel]", agentConfig);`,
    kotlin: `// Android Kotlin Native Service Module\npackage com.starai.assistant\n\nimport android.os.Bundle\n\nclass StarAiAssistantService {\n    fun initializeJarvisCore(): String {\n        println("Star AI Android Service started on port 3000")\n        return "JARVIS_ACTIVE"\n    }\n}`,
    cpp: `// High-Performance C++ Neural Execution Engine\n#include <iostream>\n\nint main() {\n    std::cout << "[Star AI C++ Matrix] Direct memory vector acceleration active.\\n";\n    return 0;\n}`,
    bash: `#!/bin/bash\necho "[Star AI Terminal] Checking system dependencies..."\nuname -a\ndf -h\necho "[Star AI Terminal] All sub-systems operational."`,
  };

  const [code, setCode] = useState<string>(defaultSnippets.python);
  const [terminalOutput, setTerminalOutput] = useState<string>(
    "[STAR AI CODE MATRIX READY]\nSelect an action or press 'RUN IN SANDBOX'."
  );
  const [explanation, setExplanation] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const handleLanguageChange = (lang: any) => {
    sciFiAudio.playSfx("click");
    setLanguage(lang);
    setCode(defaultSnippets[lang] || defaultSnippets.python);
    setTerminalOutput(`[Language switched to ${lang.toUpperCase()}]\nCode matrix initialized.`);
  };

  const handleRunCode = () => {
    sciFiAudio.playSfx("activation");
    setTerminalOutput(`[COMPILING & EXECUTING ${language.toUpperCase()}...]\n----------------------------------------\n`);
    setIsProcessing(true);

    setTimeout(() => {
      sciFiAudio.playSfx("success");
      setIsProcessing(false);
      setTerminalOutput(
        (prev) =>
          prev +
          `[PROCESS RETURNED EXIT CODE 0]\n` +
          `Outputs:\n` +
          `  -> Star AI Execution Context initialized successfully.\n` +
          `  -> Execution time: 42ms\n` +
          `  -> Memory footprint: 18.4 MB\n` +
          `\nSystem Output Stream:\n` +
          `  [STAR AI MATRIX]: Code block executed with zero heap leaks.`
      );
    }, 1000);
  };

  const handleAiAction = async (action: "optimize" | "explain" | "debug") => {
    sciFiAudio.playSfx("click");
    setIsProcessing(true);
    setTerminalOutput(`[STAR AI GEMINI MATRIX ANALYZING CODE...]\nPerforming ${action}...`);

    try {
      const res = await fetch("/api/code-assist", {
        method: "POST",
        headers: getApiHeaders(),
        body: JSON.stringify({
          code,
          language,
          action,
        }),
      });

      const data = await res.json();
      if (data.output && action === "optimize") {
        setCode(data.output);
      }
      setExplanation(data.explanation || "Code analysis completed.");
      setTerminalOutput(
        `[GEMINI ANALYSIS COMPLETE]\nAction: ${action.toUpperCase()}\n----------------------------------------\n` +
          (data.explanation || "No syntax errors detected. Optimal execution profile.")
      );
      sciFiAudio.playSfx("success");
    } catch (err) {
      setTerminalOutput("[ERROR]: Failed to reach Gemini code matrix.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    sciFiAudio.playSfx("chirp");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full p-3 sm:p-4 gap-4 font-mono select-none">
      {/* Language Bar & Actions Header */}
      <div className="flex flex-wrap items-center justify-between bg-slate-900/80 p-3 rounded-xl border border-slate-800 gap-2">
        {/* Language Tabs */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 overflow-x-auto max-w-full">
          <Code2 className="w-4 h-4 text-cyan-400 ml-1.5 mr-1" />
          {(["python", "javascript", "typescript", "kotlin", "cpp", "bash"] as const).map((lang) => (
            <button
              key={lang}
              onClick={() => handleLanguageChange(lang)}
              className={`px-2.5 py-1 rounded text-xs transition-colors uppercase font-bold ${
                language === lang
                  ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/50"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {lang}
            </button>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleRunCode}
            disabled={isProcessing}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-lg text-xs transition-colors shadow"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>RUN SANDBOX</span>
          </button>

          <button
            onClick={() => handleAiAction("optimize")}
            disabled={isProcessing}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-lg text-xs transition-colors shadow"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>OPTIMIZE (AI)</span>
          </button>

          <button
            onClick={handleCopyCode}
            className="p-1.5 bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 rounded-lg transition-colors"
            title="Copy Code"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Editor & Terminal Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Left Column: Code Editor */}
        <div className="lg:col-span-7 bg-slate-950/90 rounded-xl border border-slate-800 p-3 flex flex-col gap-2 relative">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-[10px] text-slate-400">
            <span className="flex items-center gap-1.5 text-cyan-400 font-bold">
              <Layers className="w-3.5 h-3.5" /> STAR CODE MATRIX ({language.toUpperCase()})
            </span>
            <span>UTF-8 • SYNTAX READY</span>
          </div>

          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            spellCheck={false}
            className="w-full flex-1 bg-transparent text-xs font-mono text-cyan-200 outline-none leading-relaxed resize-none p-2 selection:bg-cyan-800"
            rows={14}
          />
        </div>

        {/* Right Column: Terminal Console & AI Explainer */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          {/* Terminal Console */}
          <div className="flex-1 bg-slate-950/95 rounded-xl border border-slate-800 p-3 flex flex-col gap-2 font-mono text-xs">
            <div className="flex items-center justify-between text-[10px] text-slate-400 border-b border-slate-800 pb-2">
              <span className="flex items-center gap-1 text-emerald-400 font-bold">
                <Terminal className="w-3.5 h-3.5" /> TERMINAL STDOUT
              </span>
              <span className="animate-pulse text-emerald-500">LIVE BUS</span>
            </div>

            <pre className="flex-1 text-[11px] text-emerald-400 overflow-y-auto whitespace-pre-wrap leading-relaxed p-1">
              {terminalOutput}
            </pre>
          </div>

          {/* AI Explanation Box */}
          {explanation && (
            <div className="bg-slate-900/90 rounded-xl p-3 border border-cyan-800/60 text-xs flex flex-col gap-1">
              <div className="flex items-center gap-1 text-cyan-400 font-bold text-[10px]">
                <Sparkles className="w-3 h-3" /> STAR AI REFACTORING REPORT
              </div>
              <p className="text-slate-300 text-[11px] leading-normal">{explanation}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
