import React, { useState } from "react";
import { ListTodo, Plus, Play, CheckCircle2, Clock, AlertTriangle, Cpu, Terminal, Sparkles, RefreshCw } from "lucide-react";
import { TaskItem, TaskStep } from "../../types";
import { sciFiAudio } from "../../utils/audio";
import { getApiHeaders } from "../../utils/apiKey";

export const TaskAutomationTab: React.FC = () => {
  const [tasks, setTasks] = useState<TaskItem[]>([
    {
      id: "task-1",
      title: "Android System Optimization Routine",
      description: "Purge cached app memory, optimize battery governor, and verify NPU neural weights.",
      category: "System Maintenance",
      priority: "High",
      status: "running",
      progress: 60,
      createdAt: "10:14 AM",
      steps: [
        { id: "s1", step: "Analyze background process heap", status: "completed", details: "Memory heap cleared (1.4 GB freed)." },
        { id: "s2", step: "Recalibrate neural weight cache", status: "running", details: "Reindexing Star AI local vector database..." },
        { id: "s3", step: "Enforce battery saver governor profile", status: "pending", details: "Queued for battery manager." },
      ],
    },
    {
      id: "task-2",
      title: "Automated Daily Security Audit",
      description: "Scan network open sockets, verify TLS encryption, check API quota consumption.",
      category: "Automation",
      priority: "Medium",
      status: "completed",
      progress: 100,
      createdAt: "09:00 AM",
      steps: [
        { id: "s1", step: "Inspect port bindings", status: "completed", details: "Port 3000 bound exclusively." },
        { id: "s2", step: "Verify TLS cert validity", status: "completed", details: "AES-256 bit handshake verified." },
      ],
    },
  ]);

  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskDesc, setNewTaskDesc] = useState("");
  const [taskCategory, setTaskCategory] = useState<TaskItem["category"]>("Automation");
  const [taskPriority, setTaskPriority] = useState<TaskItem["priority"]>("High");
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedTask, setSelectedTask] = useState<TaskItem | null>(tasks[0]);

  const handleCreateTask = async () => {
    if (!newTaskTitle.trim() || isGenerating) return;
    sciFiAudio.playSfx("click");
    setIsGenerating(true);

    try {
      const res = await fetch("/api/generate-task", {
        method: "POST",
        headers: getApiHeaders(),
        body: JSON.stringify({
          taskTitle: newTaskTitle,
          taskDescription: newTaskDesc,
        }),
      });

      const data = await res.json();
      const generatedSteps: TaskStep[] = data.steps || [
        { id: "1", step: "Initialize parameters", status: "completed", details: "Ready" },
      ];

      const newTask: TaskItem = {
        id: `task-${Date.now()}`,
        title: newTaskTitle,
        description: newTaskDesc || "User automation routine.",
        category: taskCategory,
        priority: taskPriority,
        status: "pending",
        progress: 0,
        createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        steps: generatedSteps,
      };

      setTasks((prev) => [newTask, ...prev]);
      setSelectedTask(newTask);
      setNewTaskTitle("");
      setNewTaskDesc("");
      sciFiAudio.playSfx("success");
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExecuteTask = (taskId: string) => {
    sciFiAudio.playSfx("activation");
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const updatedSteps = t.steps.map((s, idx) => ({
            ...s,
            status: idx === 0 ? "completed" : idx === 1 ? "running" : ("pending" as const),
          }));
          return { ...t, status: "running", progress: 50, steps: updatedSteps };
        }
        return t;
      })
    );

    // Simulate completion after 2.5s
    setTimeout(() => {
      sciFiAudio.playSfx("success");
      setTasks((prev) =>
        prev.map((t) => {
          if (t.id === taskId) {
            const completedSteps = t.steps.map((s) => ({
              ...s,
              status: "completed" as const,
            }));
            return { ...t, status: "completed", progress: 100, steps: completedSteps };
          }
          return t;
        })
      );
    }, 2500);
  };

  return (
    <div className="flex flex-col h-full p-3 sm:p-4 gap-4 font-mono select-none">
      {/* Top Banner */}
      <div className="flex items-center justify-between bg-slate-900/80 p-3 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2">
          <ListTodo className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100 text-xs tracking-wider">
            TASK COMPLETION & GENERAL AUTOMATION ENGINE
          </span>
        </div>
        <div className="text-[10px] text-cyan-400/80 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
          {tasks.filter((t) => t.status === "running").length} ACTIVE TASKS RUNNING
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Left Column: Task Creator & Preset Macros */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          {/* Create Task Form */}
          <div className="bg-slate-900/90 rounded-xl p-4 border border-slate-800 flex flex-col gap-3">
            <div className="flex items-center gap-2 text-xs font-bold text-cyan-400">
              <Plus className="w-3.5 h-3.5" /> CREATE NEW AUTOMATION TASK
            </div>

            <input
              type="text"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder="e.g. Backup database logs & draft weekly summary"
              className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 placeholder-slate-500 outline-none focus:border-cyan-500"
            />

            <textarea
              value={newTaskDesc}
              onChange={(e) => setNewTaskDesc(e.target.value)}
              placeholder="Task parameters or automation criteria..."
              rows={2}
              className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 outline-none focus:border-cyan-500 resize-none"
            />

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">CATEGORY</label>
                <select
                  value={taskCategory}
                  onChange={(e) => setTaskCategory(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-xs text-slate-200 outline-none"
                >
                  <option value="Automation">Automation</option>
                  <option value="Code Execution">Code Execution</option>
                  <option value="Search/Scrape">Search & Scrape</option>
                  <option value="System Maintenance">System Maintenance</option>
                  <option value="Communication">Communication</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">PRIORITY</label>
                <select
                  value={taskPriority}
                  onChange={(e) => setTaskPriority(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-xs text-slate-200 outline-none"
                >
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleCreateTask}
              disabled={!newTaskTitle.trim() || isGenerating}
              className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-slate-950 font-bold rounded-lg text-xs transition-all flex items-center justify-center gap-2 mt-1"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>STAR AI BREAKING DOWN STEPS...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>GENERATE AUTOMATION PLAN</span>
                </>
              )}
            </button>
          </div>

          {/* Quick Preset Macros */}
          <div className="bg-slate-900/60 rounded-xl p-3 border border-slate-800/80 flex flex-col gap-2 text-xs">
            <span className="text-[10px] text-slate-400 font-bold uppercase">INSTANT MACRO PRESETS</span>
            <div className="flex flex-col gap-1.5">
              {[
                { title: "Smart Email Inbox Cleanse", desc: "Scan inbox and auto-draft high priority replies" },
                { title: "Neural Code Refactoring", desc: "Inspect current repository and optimize JS/Python files" },
                { title: "Edge Node Sync Sweep", desc: "Push APK packages and state files to connected Android devices" },
              ].map((macro, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setNewTaskTitle(macro.title);
                    setNewTaskDesc(macro.desc);
                  }}
                  className="text-left p-2 rounded-lg bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-slate-300 transition-all text-[11px]"
                >
                  <div className="font-bold text-cyan-300">{macro.title}</div>
                  <div className="text-[10px] text-slate-500 truncate">{macro.desc}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Task Queue & Execution Details */}
        <div className="lg:col-span-7 flex flex-col gap-3">
          {/* Task Queue List */}
          <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-800 flex flex-col gap-2 max-h-[220px] overflow-y-auto">
            <div className="text-[10px] text-slate-400 font-bold uppercase mb-1">TASK QUEUE CONTROL</div>
            {tasks.map((task) => (
              <div
                key={task.id}
                onClick={() => setSelectedTask(task)}
                className={`p-2.5 rounded-lg border cursor-pointer transition-all flex items-center justify-between ${
                  selectedTask?.id === task.id
                    ? "bg-cyan-950/60 border-cyan-500/80 text-slate-100"
                    : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-900"
                }`}
              >
                <div className="flex flex-col gap-0.5 max-w-[70%]">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs truncate">{task.title}</span>
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                        task.priority === "High"
                          ? "bg-rose-950 text-rose-300 border border-rose-800"
                          : "bg-amber-950 text-amber-300 border border-amber-800"
                      }`}
                    >
                      {task.priority}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400">{task.category} • Created {task.createdAt}</span>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${
                      task.status === "completed"
                        ? "bg-emerald-950 text-emerald-300 border-emerald-800"
                        : task.status === "running"
                        ? "bg-cyan-950 text-cyan-300 border-cyan-800 animate-pulse"
                        : "bg-slate-900 text-slate-400 border-slate-800"
                    }`}
                  >
                    {task.status}
                  </span>
                  {task.status !== "completed" && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleExecuteTask(task.id);
                      }}
                      className="p-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 rounded-md transition-colors"
                      title="Run Task"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Selected Task Step Execution Log */}
          {selectedTask && (
            <div className="flex-1 bg-slate-900/90 rounded-xl p-4 border border-slate-800 flex flex-col gap-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <h4 className="font-bold text-sm text-cyan-300">{selectedTask.title}</h4>
                  <p className="text-[11px] text-slate-400">{selectedTask.description}</p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">PROGRESS</span>
                  <span className="text-sm font-bold text-cyan-400">{selectedTask.progress}%</span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-cyan-500 transition-all duration-500"
                  style={{ width: `${selectedTask.progress}%` }}
                />
              </div>

              {/* Steps List */}
              <div className="flex flex-col gap-2 mt-1 overflow-y-auto max-h-[180px]">
                <span className="text-[10px] text-slate-400 font-bold uppercase">EXECUTION STEPS LOG</span>
                {selectedTask.steps.map((step, idx) => (
                  <div
                    key={step.id || idx}
                    className="p-2 bg-slate-950/80 rounded-lg border border-slate-800/80 flex items-start gap-2 text-xs"
                  >
                    {step.status === "completed" ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    ) : step.status === "running" ? (
                      <RefreshCw className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5 animate-spin" />
                    ) : (
                      <Clock className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <div className="font-bold text-slate-200">
                        Step {idx + 1}: {step.step}
                      </div>
                      <div className="text-[10px] text-slate-400">{step.details}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
