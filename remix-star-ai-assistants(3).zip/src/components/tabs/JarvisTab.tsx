import React, { useState, useRef, useEffect } from "react";
import { Mic, MicOff, Send, Volume2, Sparkles, Terminal, Play, Bot, User, RefreshCw } from "lucide-react";
import { ChatMessage, PersonalityMode } from "../../types";
import { HoloOrbVisualizer } from "../HoloOrbVisualizer";
import { sciFiAudio } from "../../utils/audio";
import { getApiHeaders } from "../../utils/apiKey";

interface JarvisTabProps {
  personality: PersonalityMode;
  activeEmotion: string;
  themeColor: "cyan" | "magenta" | "gold" | "emerald";
  onTriggerTask: (title: string) => void;
}

export const JarvisTab: React.FC<JarvisTabProps> = ({
  personality,
  activeEmotion,
  themeColor,
  onTriggerTask,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      sender: "assistant",
      text: `Greetings. Star AI Assistant core initialized in [${personality}] mode. All neural subsystems, voice recognition, and task engines are standing by. How may I serve you?`,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  // Handle Speech Recognition setup
  const toggleListening = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      sciFiAudio.playSfx("click");
      return;
    }

    if (typeof window === "undefined") return;
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser. You can type commands directly.");
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = "en-US";

      recognition.onstart = () => {
        setIsListening(true);
        sciFiAudio.playSfx("activation");
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsListening(false);
        sciFiAudio.playSfx("chirp");
        handleSendMessage(transcript);
      };

      recognition.onerror = (err: any) => {
        console.error("Speech Error:", err);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (e) {
      console.error(e);
      setIsListening(false);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || isLoading) return;

    sciFiAudio.playSfx("click");
    setInputText("");

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: "user",
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setIsLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: getApiHeaders(),
        body: JSON.stringify({
          message: text,
          personality,
          emotionContext: activeEmotion,
        }),
      });

      const data = await res.json();
      const replyText = data.reply || "Command executed successfully.";

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: "assistant",
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      setMessages((prev) => [...prev, aiMsg]);

      // Auto speak if enabled
      if (autoSpeak) {
        setIsSpeaking(true);
        sciFiAudio.speak(replyText);
        setTimeout(() => setIsSpeaking(false), Math.min(replyText.length * 50, 6000));
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: "system",
          text: "Communication bus error. Unable to reach Star AI core.",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full p-3 sm:p-4 gap-4 font-mono select-none">
      {/* Top Holographic Reactor Core Orb Header */}
      <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col md:flex-row items-center justify-around gap-4 relative overflow-hidden">
        {/* Decorative Grid Lines */}
        <div className="absolute inset-0 bg-[radial-gradient(#06b6d4_1px,transparent_1px)] [background-size:16px_16px] opacity-10 pointer-events-none" />

        {/* Holo Reactor Orb Visualizer */}
        <HoloOrbVisualizer
          isListening={isListening}
          isSpeaking={isSpeaking}
          activeEmotion={activeEmotion}
          themeColor={themeColor}
          size={220}
        />

        {/* Quick Voice Command Prompts */}
        <div className="flex-1 max-w-md w-full flex flex-col gap-2 z-10">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1 text-cyan-400 font-bold">
              <Sparkles className="w-3.5 h-3.5" /> VOICE SHORTCUT MACROS
            </span>
            <button
              onClick={() => setAutoSpeak(!autoSpeak)}
              className={`flex items-center gap-1 text-[10px] px-2 py-0.5 rounded border transition-colors ${
                autoSpeak
                  ? "bg-cyan-950 text-cyan-300 border-cyan-800"
                  : "bg-slate-950 text-slate-500 border-slate-800"
              }`}
            >
              <Volume2 className="w-3 h-3" />
              <span>TTS READ: {autoSpeak ? "ON" : "MUTED"}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {[
              "Execute daily system diagnostic",
              "Draft executive email response",
              "Search quantum AI benchmarks",
              "Initiate node replication protocol",
            ].map((shortcut, idx) => (
              <button
                key={idx}
                onClick={() => {
                  sciFiAudio.playSfx("click");
                  handleSendMessage(shortcut);
                }}
                className="text-left text-[11px] p-2 rounded-lg bg-slate-950/80 border border-slate-800/80 hover:border-cyan-500/50 hover:bg-cyan-950/30 text-slate-300 hover:text-cyan-200 transition-all flex items-center justify-between group"
              >
                <span className="truncate">{shortcut}</span>
                <Play className="w-3 h-3 text-cyan-500 opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Conversation Terminal Stream */}
      <div className="flex-1 min-h-[300px] max-h-[420px] bg-slate-950/90 rounded-2xl border border-slate-800 p-3 sm:p-4 overflow-y-auto flex flex-col gap-3 shadow-inner">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col max-w-[88%] ${
              msg.sender === "user"
                ? "self-end items-end"
                : msg.sender === "system"
                ? "self-center items-center text-rose-400"
                : "self-start items-start"
            }`}
          >
            <div className="flex items-center gap-1.5 mb-1 text-[10px] text-slate-500">
              {msg.sender === "user" ? (
                <>
                  <span>YOU</span>
                  <User className="w-3 h-3 text-cyan-400" />
                </>
              ) : (
                <>
                  <Bot className="w-3 h-3 text-cyan-400" />
                  <span className="font-bold text-cyan-400">{personality}</span>
                </>
              )}
              <span>• {msg.timestamp}</span>
            </div>

            <div
              className={`p-3 rounded-2xl text-xs leading-relaxed ${
                msg.sender === "user"
                  ? "bg-cyan-950/60 border border-cyan-800/60 text-slate-100 rounded-tr-none"
                  : msg.sender === "system"
                  ? "bg-rose-950/40 border border-rose-900/60 text-rose-300 text-center"
                  : "bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none shadow-md"
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="self-start flex items-center gap-2 p-3 bg-slate-900/60 border border-slate-800 rounded-2xl text-xs text-cyan-400">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
            <span>Star AI synthesizing response...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Voice Command & Text Input Controls */}
      <div className="flex items-center gap-2">
        {/* Voice Recognition Mic Button */}
        <button
          onClick={toggleListening}
          className={`p-3 rounded-xl border transition-all flex items-center justify-center ${
            isListening
              ? "bg-rose-600 text-white border-rose-400 ring-4 ring-rose-500/30 animate-pulse"
              : "bg-cyan-950 text-cyan-400 border-cyan-800 hover:bg-cyan-900 hover:border-cyan-500"
          }`}
          title={isListening ? "Stop Voice Input" : "Start Voice Input"}
        >
          {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {/* Text Input Field */}
        <div className="flex-1 flex items-center bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 focus-within:border-cyan-500/80 transition-colors">
          <Terminal className="w-4 h-4 text-slate-500 mr-2" />
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
            placeholder={
              isListening ? "Listening to your voice..." : "Enter command or ask Star AI..."
            }
            className="w-full bg-transparent text-xs text-slate-200 placeholder-slate-500 outline-none font-mono"
          />
        </div>

        {/* Send Button */}
        <button
          onClick={() => handleSendMessage()}
          disabled={!inputText.trim() || isLoading}
          className="p-3 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-slate-950 font-bold rounded-xl transition-all shadow-lg flex items-center justify-center"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
