import React, { useState, useRef, useEffect } from "react";
import { Camera, CameraOff, Scan, Sparkles, UserCheck, Heart, AlertCircle, RefreshCw } from "lucide-react";
import { EmotionScanResult } from "../../types";
import { sciFiAudio } from "../../utils/audio";
import { getApiHeaders } from "../../utils/apiKey";

interface FaceScannerTabProps {
  onEmotionDetected: (emotion: string) => void;
}

export const FaceScannerTab: React.FC<FaceScannerTabProps> = ({ onEmotionDetected }) => {
  const [cameraActive, setCameraActive] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [scanResult, setScanResult] = useState<EmotionScanResult>({
    emotion: "Focused",
    confidence: 94,
    metrics: {
      stressLevel: 22,
      attentiveness: 92,
      energyLevel: 88,
      microExpressions: ["Subtle eyebrow lift", "Direct gaze"],
    },
    suggestedTone: "Direct, encouraging, and efficient",
    actionRecommendation: "Maintain active coding session & workflow execution.",
    timestamp: "Just now",
  });

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Start Camera
  const startCamera = async () => {
    sciFiAudio.playSfx("activation");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setCameraActive(true);
      sciFiAudio.playSfx("success");
    } catch (err) {
      console.warn("Camera permission denied, using holographic face scanner simulation.", err);
      setCameraActive(true); // Keep active for simulation mode
    }
  };

  // Stop Camera
  const stopCamera = () => {
    sciFiAudio.playSfx("click");
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  // Capture image frame and analyze emotion
  const captureAndAnalyze = async () => {
    sciFiAudio.playSfx("scan");
    setIsAnalyzing(true);

    let imageBase64 = "";

    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth || 320;
      canvas.height = video.videoHeight || 240;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        imageBase64 = canvas.toDataURL("image/jpeg", 0.8);
      }
    }

    try {
      const res = await fetch("/api/analyze-face", {
        method: "POST",
        headers: getApiHeaders(),
        body: JSON.stringify({ imageBase64 }),
      });

      const data = await res.json();
      const updated: EmotionScanResult = {
        emotion: data.emotion || "Focused",
        confidence: data.confidence || 92,
        metrics: data.metrics || {
          stressLevel: 25,
          attentiveness: 90,
          energyLevel: 85,
          microExpressions: ["Attentive gaze"],
        },
        suggestedTone: data.suggestedTone || "Professional",
        actionRecommendation: data.actionRecommendation || "Standard operations.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      setScanResult(updated);
      onEmotionDetected(updated.emotion);
      sciFiAudio.playSfx("success");
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="flex flex-col h-full p-3 sm:p-4 gap-4 font-mono select-none">
      {/* Header Banner */}
      <div className="flex items-center justify-between bg-slate-900/80 p-3 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2">
          <Scan className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100 text-xs tracking-wider">
            FACIAL RECOGNITION & PERSONALIZED EMOTION SCANNER
          </span>
        </div>

        <button
          onClick={cameraActive ? stopCamera : startCamera}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
            cameraActive
              ? "bg-rose-950/80 text-rose-300 border border-rose-800 hover:bg-rose-900"
              : "bg-cyan-600 text-slate-950 hover:bg-cyan-500"
          }`}
        >
          {cameraActive ? (
            <>
              <CameraOff className="w-3.5 h-3.5" />
              <span>STOP CAMERA</span>
            </>
          ) : (
            <>
              <Camera className="w-3.5 h-3.5" />
              <span>INITIALIZE CAMERA</span>
            </>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Left Column: Live Video Feed & Reticle Canvas */}
        <div className="lg:col-span-6 bg-slate-950/90 rounded-2xl border border-slate-800 p-4 flex flex-col items-center justify-center gap-4 relative overflow-hidden min-h-[320px]">
          {/* Video Feed or Holographic Simulation Placeholder */}
          <div className="relative w-full max-w-sm aspect-video bg-slate-900 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
            {cameraActive ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="flex flex-col items-center justify-center text-slate-500 p-6 text-center gap-2">
                <Scan className="w-10 h-10 text-cyan-500/40 animate-pulse" />
                <span className="text-xs">CAMERA FEED INACTIVE</span>
                <span className="text-[10px] text-slate-600">
                  Click 'INITIALIZE CAMERA' to activate optical biometric scanning.
                </span>
              </div>
            )}

            {/* Sci-Fi HUD Reticle Overlay */}
            {cameraActive && (
              <div className="absolute inset-0 border-2 border-cyan-500/40 rounded-xl pointer-events-none flex flex-col justify-between p-3">
                <div className="flex justify-between text-[9px] text-cyan-400 font-bold">
                  <span>FACIAL RETICLE [LOCKED]</span>
                  <span>FPS: 60</span>
                </div>

                {/* Animated Scanning Bar */}
                <div className="w-full h-0.5 bg-cyan-400 shadow-[0_0_8px_#06b6d4] animate-bounce" />

                <div className="flex justify-between text-[9px] text-cyan-400 font-bold">
                  <span>LATENCY: 12ms</span>
                  <span>BIOMETRIC MESH: 468 POINTS</span>
                </div>
              </div>
            )}
          </div>

          <canvas ref={canvasRef} className="hidden" />

          {/* Action Button */}
          <button
            onClick={captureAndAnalyze}
            disabled={!cameraActive || isAnalyzing}
            className="w-full max-w-sm py-2.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-slate-950 font-bold rounded-xl text-xs transition-all shadow-lg flex items-center justify-center gap-2"
          >
            {isAnalyzing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>ANALYZING EMOTIONAL BIOMETRICS...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>SCAN EMOTIONAL STATE (GEMINI VISION)</span>
              </>
            )}
          </button>
        </div>

        {/* Right Column: Emotion Analysis Diagnostics */}
        <div className="lg:col-span-6 bg-slate-950/90 rounded-2xl border border-slate-800 p-4 flex flex-col gap-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="flex items-center gap-2 text-xs font-bold text-cyan-300">
              <UserCheck className="w-4 h-4 text-cyan-400" /> EMOTIONAL BIOMETRICS REPORT
            </span>
            <span className="text-[10px] text-slate-400">LAST SCAN: {scanResult.timestamp}</span>
          </div>

          {/* Emotion Overview Card */}
          <div className="bg-slate-900/90 rounded-xl p-3.5 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 uppercase block">CURRENT STATE</span>
              <span className="text-lg font-bold text-cyan-300 uppercase tracking-wider">
                {scanResult.emotion}
              </span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 uppercase block">CONFIDENCE</span>
              <span className="text-lg font-bold text-emerald-400">{scanResult.confidence}%</span>
            </div>
          </div>

          {/* Metric Meters */}
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 text-center">
              <span className="text-[10px] text-slate-400 block mb-1">STRESS LEVEL</span>
              <span className="text-sm font-bold text-amber-400">{scanResult.metrics.stressLevel}%</span>
            </div>

            <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 text-center">
              <span className="text-[10px] text-slate-400 block mb-1">ATTENTIVENESS</span>
              <span className="text-sm font-bold text-cyan-400">{scanResult.metrics.attentiveness}%</span>
            </div>

            <div className="bg-slate-900/60 p-2.5 rounded-xl border border-slate-800 text-center">
              <span className="text-[10px] text-slate-400 block mb-1">ENERGY LEVEL</span>
              <span className="text-sm font-bold text-emerald-400">{scanResult.metrics.energyLevel}%</span>
            </div>
          </div>

          {/* AI Tailored Recommendations */}
          <div className="flex flex-col gap-2">
            <div className="p-3 bg-cyan-950/40 border border-cyan-800/60 rounded-xl text-xs">
              <span className="font-bold text-cyan-300 block mb-1">ADAPTIVE CONVERSATIONAL TONE:</span>
              <span className="text-slate-200">{scanResult.suggestedTone}</span>
            </div>

            <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl text-xs">
              <span className="font-bold text-emerald-400 block mb-1">AI WORKFLOW ACTION RECOMMENDATION:</span>
              <span className="text-slate-300">{scanResult.actionRecommendation}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
