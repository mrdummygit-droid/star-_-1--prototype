import React, { useState, useEffect } from "react";
import { Smartphone, Download, Share2, Copy, Check, X, QrCode, ExternalLink, ShieldCheck, Sparkles } from "lucide-react";
import { sciFiAudio } from "../utils/audio";

interface InstallPwaModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallPwaModal: React.FC<InstallPwaModalProps> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  // App URL for sharing to Android phone
  const appShareUrl =
    typeof window !== "undefined"
      ? window.location.origin
      : "https://ais-pre-gg2tabvuse6kvjd46tsqyy-825413863631.asia-east1.run.app";

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    sciFiAudio.playSfx("scan");
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        sciFiAudio.playSfx("success");
        setInstallSuccess(true);
      }
      setDeferredPrompt(null);
    } else {
      sciFiAudio.playSfx("chirp");
    }
  };

  const handleCopyLink = () => {
    sciFiAudio.playSfx("click");
    navigator.clipboard.writeText(appShareUrl);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md font-mono select-none">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl flex flex-col gap-4 relative overflow-hidden">
        {/* Glow header accent */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 via-cyan-400 to-blue-500" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-cyan-950/90 border border-cyan-800 rounded-xl text-cyan-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-100 tracking-wider flex items-center gap-2">
                INSTALL ON ANDROID
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-normal">
                  PWA APP
                </span>
              </h3>
              <p className="text-[10px] text-slate-400">RUN STAR AI DIRECTLY ON YOUR MOBILE HOME SCREEN</p>
            </div>
          </div>

          <button
            onClick={() => {
              sciFiAudio.playSfx("click");
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success State */}
        {installSuccess ? (
          <div className="p-4 bg-emerald-950/60 border border-emerald-800 rounded-xl text-center space-y-2">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-400 text-emerald-400 flex items-center justify-center mx-auto">
              <Check className="w-6 h-6" />
            </div>
            <h4 className="font-bold text-sm text-emerald-300">STAR AI INSTALLED ON YOUR DEVICE!</h4>
            <p className="text-xs text-slate-300">
              Check your Android home screen or app drawer for the <strong>Star AI</strong> launcher icon.
            </p>
          </div>
        ) : (
          <>
            {/* Direct Native Install Button if prompt ready */}
            {deferredPrompt && (
              <button
                onClick={handleInstallClick}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50"
              >
                <Download className="w-4 h-4" />
                <span>TAP TO INSTALL STAR AI APP ON ANDROID</span>
              </button>
            )}

            {/* Shareable Link Section */}
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-300 font-bold">
                <span className="flex items-center gap-1.5 text-cyan-400">
                  <Share2 className="w-3.5 h-3.5" />
                  <span>APP LINK FOR MOBILE PHONE</span>
                </span>
                <span className="text-[10px] text-slate-500">HTTPS READY</span>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={appShareUrl}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 outline-none font-mono"
                />
                <button
                  onClick={handleCopyLink}
                  className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-lg text-xs transition-colors flex items-center gap-1 shrink-0"
                >
                  {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{isCopied ? "COPIED!" : "COPY LINK"}</span>
                </button>
              </div>
            </div>

            {/* Step-by-Step Android Installation Guide */}
            <div className="space-y-2">
              <h4 className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>HOW TO INSTALL ON ANDROID CHROME</span>
              </h4>

              <div className="space-y-1.5 text-xs text-slate-300">
                <div className="p-2.5 bg-slate-950/80 border border-slate-800/80 rounded-xl flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-800 text-cyan-400 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </span>
                  <div>
                    <span className="font-bold text-slate-100">Open Link in Chrome:</span> Copy the link above and open it in <strong>Google Chrome</strong> on your Android phone.
                  </div>
                </div>

                <div className="p-2.5 bg-slate-950/80 border border-slate-800/80 rounded-xl flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-800 text-cyan-400 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </span>
                  <div>
                    <span className="font-bold text-slate-100">Tap Chrome Menu:</span> Tap the <strong>3 dots (⋮)</strong> in the top-right corner of Google Chrome.
                  </div>
                </div>

                <div className="p-2.5 bg-slate-950/80 border border-slate-800/80 rounded-xl flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-800 text-cyan-400 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    3
                  </span>
                  <div>
                    <span className="font-bold text-slate-100">Tap "Add to Home screen":</span> Choose <strong>"Add to Home screen"</strong> or <strong>"Install app"</strong>.
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Footer info */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-500">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            STANDALONE FULLSCREEN APPLICATION
          </span>
          <button
            onClick={() => {
              sciFiAudio.playSfx("click");
              onClose();
            }}
            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-bold"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
