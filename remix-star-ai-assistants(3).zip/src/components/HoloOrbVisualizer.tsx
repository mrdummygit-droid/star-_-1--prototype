import React, { useEffect, useRef } from "react";

interface HoloOrbProps {
  isListening?: boolean;
  isSpeaking?: boolean;
  activeEmotion?: string;
  themeColor?: "cyan" | "magenta" | "gold" | "emerald";
  size?: number;
}

export const HoloOrbVisualizer: React.FC<HoloOrbProps> = ({
  isListening = false,
  isSpeaking = false,
  activeEmotion = "Calm",
  themeColor = "cyan",
  size = 280,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Map theme colors to RGB triples
  const getThemeRgb = () => {
    switch (themeColor) {
      case "magenta":
        return { r: 236, g: 72, b: 153, main: "#ec4899" };
      case "gold":
        return { r: 245, g: 158, b: 11, main: "#f59e0b" };
      case "emerald":
        return { r: 16, g: 185, b: 129, main: "#10b981" };
      case "cyan":
      default:
        return { r: 6, g: 182, b: 212, main: "#06b6d4" };
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let angle = 0;
    let pulseTime = 0;

    // Particle field around orb
    const particles: Array<{
      x: number;
      y: number;
      radius: number;
      speed: number;
      angle: number;
      dist: number;
      alpha: number;
    }> = [];

    const color = getThemeRgb();

    for (let i = 0; i < 40; i++) {
      particles.push({
        x: 0,
        y: 0,
        radius: Math.random() * 2 + 0.5,
        speed: Math.random() * 0.02 + 0.005,
        angle: Math.random() * Math.PI * 2,
        dist: Math.random() * (size * 0.45) + size * 0.1,
        alpha: Math.random() * 0.7 + 0.3,
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;
      const baseRadius = size * 0.28;

      angle += 0.015;
      pulseTime += isSpeaking ? 0.08 : isListening ? 0.05 : 0.02;

      // Dynamic scale pulsing
      const pulse = Math.sin(pulseTime) * (isSpeaking ? 8 : isListening ? 5 : 2);
      const orbRadius = baseRadius + pulse;

      // 1. Draw Background Glow Aura
      const glowGrad = ctx.createRadialGradient(cx, cy, 5, cx, cy, orbRadius * 2);
      glowGrad.addColorStop(0, `rgba(${color.r}, ${color.g}, ${color.b}, 0.35)`);
      glowGrad.addColorStop(0.5, `rgba(${color.r}, ${color.g}, ${color.b}, 0.12)`);
      glowGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, orbRadius * 2, 0, Math.PI * 2);
      ctx.fill();

      // 2. Draw Center Plasma Sphere
      const sphereGrad = ctx.createRadialGradient(
        cx - orbRadius * 0.3,
        cy - orbRadius * 0.3,
        2,
        cx,
        cy,
        orbRadius
      );
      sphereGrad.addColorStop(0, "#ffffff");
      sphereGrad.addColorStop(0.4, `rgba(${color.r}, ${color.g}, ${color.b}, 0.9)`);
      sphereGrad.addColorStop(0.8, `rgba(${Math.max(0, color.r - 40)}, ${Math.max(0, color.g - 40)}, ${Math.max(0, color.b - 40)}, 0.6)`);
      sphereGrad.addColorStop(1, "rgba(2, 6, 23, 0.9)");

      ctx.fillStyle = sphereGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, orbRadius, 0, Math.PI * 2);
      ctx.fill();

      // 3. Rotating Holographic Outer Rings
      // Ring 1 - Fast Clockwise
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(angle * 1.2);
      ctx.strokeStyle = `rgba(${color.r}, ${color.g}, ${color.b}, 0.8)`;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([12, 18, 6, 12]);
      ctx.beginPath();
      ctx.arc(0, 0, orbRadius * 1.35, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Ring 2 - Counter-Clockwise
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-angle * 0.8);
      ctx.strokeStyle = `rgba(255, 255, 255, 0.6)`;
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 24, 18, 8]);
      ctx.beginPath();
      ctx.arc(0, 0, orbRadius * 1.55, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Ring 3 - Outer Thin Tick Marks
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(angle * 0.4);
      ctx.strokeStyle = `rgba(${color.r}, ${color.g}, ${color.b}, 0.4)`;
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 8]);
      ctx.beginPath();
      ctx.arc(0, 0, orbRadius * 1.75, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // 4. Audio Frequency Waveform (If Listening or Speaking)
      if (isListening || isSpeaking) {
        ctx.save();
        ctx.translate(cx, cy);
        const waveCount = 36;
        for (let i = 0; i < waveCount; i++) {
          const a = (i / waveCount) * Math.PI * 2;
          const h = (Math.sin(pulseTime * 2 + i) + 1) * (isSpeaking ? 16 : 8) + 4;
          const x1 = Math.cos(a) * (orbRadius * 1.1);
          const y1 = Math.sin(a) * (orbRadius * 1.1);
          const x2 = Math.cos(a) * (orbRadius * 1.1 + h);
          const y2 = Math.sin(a) * (orbRadius * 1.1 + h);

          ctx.strokeStyle = `rgba(${color.r}, ${color.g}, ${color.b}, ${0.5 + (i % 2) * 0.4})`;
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
        }
        ctx.restore();
      }

      // 5. Draw Orbiting Particle Swarm
      particles.forEach((p) => {
        p.angle += p.speed;
        const px = cx + Math.cos(p.angle) * p.dist;
        const py = cy + Math.sin(p.angle) * p.dist;

        ctx.fillStyle = `rgba(${color.r}, ${color.g}, ${color.b}, ${p.alpha})`;
        ctx.beginPath();
        ctx.arc(px, py, p.radius, 0, Math.PI * 2);
        ctx.fill();
      });

      // 6. Reticle Crosshairs
      ctx.strokeStyle = `rgba(${color.r}, ${color.g}, ${color.b}, 0.25)`;
      ctx.lineWidth = 1;

      // Top-Left reticle bracket
      ctx.beginPath();
      ctx.moveTo(cx - orbRadius * 1.8, cy - orbRadius * 1.4);
      ctx.lineTo(cx - orbRadius * 1.8, cy - orbRadius * 1.8);
      ctx.lineTo(cx - orbRadius * 1.4, cy - orbRadius * 1.8);
      ctx.stroke();

      // Top-Right reticle bracket
      ctx.beginPath();
      ctx.moveTo(cx + orbRadius * 1.8, cy - orbRadius * 1.4);
      ctx.lineTo(cx + orbRadius * 1.8, cy - orbRadius * 1.8);
      ctx.lineTo(cx + orbRadius * 1.4, cy - orbRadius * 1.8);
      ctx.stroke();

      // Bottom-Left reticle bracket
      ctx.beginPath();
      ctx.moveTo(cx - orbRadius * 1.8, cy + orbRadius * 1.4);
      ctx.lineTo(cx - orbRadius * 1.8, cy + orbRadius * 1.8);
      ctx.lineTo(cx - orbRadius * 1.4, cy + orbRadius * 1.8);
      ctx.stroke();

      // Bottom-Right reticle bracket
      ctx.beginPath();
      ctx.moveTo(cx + orbRadius * 1.8, cy + orbRadius * 1.4);
      ctx.lineTo(cx + orbRadius * 1.8, cy + orbRadius * 1.8);
      ctx.lineTo(cx + orbRadius * 1.4, cy + orbRadius * 1.8);
      ctx.stroke();

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isListening, isSpeaking, activeEmotion, themeColor, size]);

  return (
    <div className="relative flex flex-col items-center justify-center">
      <canvas
        ref={canvasRef}
        width={size}
        height={size}
        className="cursor-pointer transition-transform duration-300 hover:scale-105"
      />
      <div className="mt-2 text-center">
        <div className="flex items-center justify-center gap-2 text-xs font-mono tracking-widest text-cyan-400/90 uppercase">
          <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span>
            {isSpeaking
              ? "STAR AI RESPONDING..."
              : isListening
              ? "VOICE RECOGNITION ACTIVE"
              : `CORE REACTOR • ${activeEmotion.toUpperCase()}`}
          </span>
        </div>
      </div>
    </div>
  );
};
