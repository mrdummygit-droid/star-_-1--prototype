// Multi-Provider API Key & Configuration Utility for Star AI Assistant

export type AIProvider = "gemini" | "openrouter" | "openai" | "anthropic" | "deepseek" | "groq";

export interface ProviderConfig {
  id: AIProvider;
  name: string;
  defaultModel: string;
  keyPrefix: string;
  keyHelpUrl: string;
  placeholder: string;
  models: { id: string; name: string }[];
}

export const PROVIDERS: Record<AIProvider, ProviderConfig> = {
  gemini: {
    id: "gemini",
    name: "Google Gemini",
    defaultModel: "gemini-3.6-flash",
    keyPrefix: "AIzaSy...",
    keyHelpUrl: "https://aistudio.google.com/app/apikey",
    placeholder: "AIzaSy...",
    models: [
      { id: "gemini-3.6-flash", name: "Gemini 3.6 Flash (Recommended)" },
      { id: "gemini-2.5-pro", name: "Gemini 2.5 Pro (Deep Reasoning)" },
      { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash" },
    ],
  },
  openrouter: {
    id: "openrouter",
    name: "OpenRouter AI",
    defaultModel: "openrouter/auto",
    keyPrefix: "sk-or-...",
    keyHelpUrl: "https://openrouter.ai/keys",
    placeholder: "sk-or-v1-...",
    models: [
      { id: "openrouter/auto", name: "OpenRouter Auto Router" },
      { id: "deepseek/deepseek-r1", name: "DeepSeek R1 (Reasoning)" },
      { id: "deepseek/deepseek-chat", name: "DeepSeek V3" },
      { id: "openai/gpt-4o-mini", name: "OpenAI GPT-4o Mini" },
      { id: "anthropic/claude-3.5-sonnet", name: "Claude 3.5 Sonnet" },
      { id: "meta-llama/llama-3.3-70b-instruct", name: "Meta Llama 3.3 70B" },
      { id: "google/gemini-2.0-flash-001", name: "Google Gemini 2.0 Flash" },
    ],
  },
  openai: {
    id: "openai",
    name: "OpenAI",
    defaultModel: "gpt-4o-mini",
    keyPrefix: "sk-...",
    keyHelpUrl: "https://platform.openai.com/api-keys",
    placeholder: "sk-proj-...",
    models: [
      { id: "gpt-4o-mini", name: "GPT-4o Mini (Fast & Cheap)" },
      { id: "gpt-4o", name: "GPT-4o (Omni High Intelligence)" },
      { id: "o3-mini", name: "o3-mini (Reasoning)" },
    ],
  },
  anthropic: {
    id: "anthropic",
    name: "Anthropic Claude",
    defaultModel: "claude-3-5-haiku-20241022",
    keyPrefix: "sk-ant-...",
    keyHelpUrl: "https://console.anthropic.com/settings/keys",
    placeholder: "sk-ant-api03-...",
    models: [
      { id: "claude-3-5-haiku-20241022", name: "Claude 3.5 Haiku" },
      { id: "claude-3-5-sonnet-20241022", name: "Claude 3.5 Sonnet" },
    ],
  },
  deepseek: {
    id: "deepseek",
    name: "DeepSeek Direct",
    defaultModel: "deepseek-chat",
    keyPrefix: "sk-...",
    keyHelpUrl: "https://platform.deepseek.com/api_keys",
    placeholder: "sk-...",
    models: [
      { id: "deepseek-chat", name: "DeepSeek V3 (Chat)" },
      { id: "deepseek-reasoner", name: "DeepSeek R1 (Reasoner)" },
    ],
  },
  groq: {
    id: "groq",
    name: "Groq LPU",
    defaultModel: "llama-3.3-70b-versatile",
    keyPrefix: "gsk_...",
    keyHelpUrl: "https://console.groq.com/keys",
    placeholder: "gsk_...",
    models: [
      { id: "llama-3.3-70b-versatile", name: "Llama 3.3 70B Versatile" },
      { id: "mixtral-8x7b-32768", name: "Mixtral 8x7B" },
      { id: "deepseek-r1-distill-llama-70b", name: "DeepSeek R1 Distill 70B" },
    ],
  },
};

const STORAGE_ACTIVE_PROVIDER = "star_ai_active_provider";
const STORAGE_PROVIDER_KEY_PREFIX = "star_ai_key_";
const STORAGE_PROVIDER_MODEL_PREFIX = "star_ai_model_";

export function getActiveProvider(): AIProvider {
  if (typeof window === "undefined") return "gemini";
  return (localStorage.getItem(STORAGE_ACTIVE_PROVIDER) as AIProvider) || "gemini";
}

export function setActiveProvider(provider: AIProvider): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_ACTIVE_PROVIDER, provider);
}

export function getProviderApiKey(provider: AIProvider): string {
  if (typeof window === "undefined") return "";
  return localStorage.getItem(`${STORAGE_PROVIDER_KEY_PREFIX}${provider}`) || "";
}

export function setProviderApiKey(provider: AIProvider, key: string): void {
  if (typeof window === "undefined") return;
  if (key.trim()) {
    localStorage.setItem(`${STORAGE_PROVIDER_KEY_PREFIX}${provider}`, key.trim());
  } else {
    localStorage.removeItem(`${STORAGE_PROVIDER_KEY_PREFIX}${provider}`);
  }
}

export function getProviderModel(provider: AIProvider): string {
  if (typeof window === "undefined") return PROVIDERS[provider]?.defaultModel || "";
  return (
    localStorage.getItem(`${STORAGE_PROVIDER_MODEL_PREFIX}${provider}`) ||
    PROVIDERS[provider]?.defaultModel ||
    ""
  );
}

export function setProviderModel(provider: AIProvider, model: string): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(`${STORAGE_PROVIDER_MODEL_PREFIX}${provider}`, model);
}

// Auto-detect provider from key format
export function detectProviderFromKey(key: string): AIProvider | null {
  const k = key.trim();
  if (k.startsWith("sk-or-")) return "openrouter";
  if (k.startsWith("gsk_")) return "groq";
  if (k.startsWith("sk-ant-")) return "anthropic";
  if (k.startsWith("AIzaSy")) return "gemini";
  return null;
}

// Legacy helper compatibility
export function getStoredApiKey(): string {
  const provider = getActiveProvider();
  return getProviderApiKey(provider);
}

export function setStoredApiKey(key: string): void {
  const detected = detectProviderFromKey(key) || getActiveProvider();
  setActiveProvider(detected);
  setProviderApiKey(detected, key);
}

export function clearStoredApiKey(): void {
  const provider = getActiveProvider();
  setProviderApiKey(provider, "");
}

export function getApiHeaders(contentType = "application/json"): Record<string, string> {
  const headers: Record<string, string> = {
    "Content-Type": contentType,
  };

  const provider = getActiveProvider();
  const apiKey = getProviderApiKey(provider);
  const model = getProviderModel(provider);

  headers["x-provider"] = provider;
  if (apiKey) {
    headers["x-api-key"] = apiKey;
  }
  if (model) {
    headers["x-model"] = model;
  }

  return headers;
}
