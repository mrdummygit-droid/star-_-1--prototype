export type TabType =
  | "jarvis"
  | "tasks"
  | "code"
  | "search"
  | "face"
  | "email"
  | "files"
  | "api"
  | "replication";

export type PersonalityMode =
  | "STARK-I"
  | "CYBER-TACTICIAN"
  | "QUANTUM-RESEARCHER"
  | "CREATIVE-SYNTH";

export interface TaskStep {
  id: string;
  step: string;
  status: "pending" | "running" | "completed" | "failed";
  details: string;
}

export interface TaskItem {
  id: string;
  title: string;
  description?: string;
  category: "Automation" | "Code Execution" | "Search/Scrape" | "System Maintenance" | "Communication";
  priority: "High" | "Medium" | "Low";
  status: "pending" | "running" | "completed" | "failed";
  steps: TaskStep[];
  progress: number;
  createdAt: string;
  scheduledTime?: string;
}

export interface EmailItem {
  id: string;
  sender: string;
  recipient: string;
  subject: string;
  body: string;
  timestamp: string;
  read: boolean;
  priority: "High" | "Normal" | "Low";
  tags: string[];
}

export interface FileItem {
  id: string;
  name: string;
  size: string;
  type: "file" | "folder";
  path: string;
  mimeType: string;
  content?: string;
  modified: string;
}

export interface ApiKeyItem {
  id: string;
  provider: "Gemini" | "OpenAI" | "Anthropic" | "DeepSeek" | "ElevenLabs" | "HuggingFace" | "Custom Webhook";
  label: string;
  key: string;
  isConnected: boolean;
  latency: number;
  usageQuota: string;
  isPrimary?: boolean;
}

export interface NodeDevice {
  id: string;
  name: string;
  ip: string;
  deviceType: "Android Mobile" | "Tablet OS" | "Linux Edge Node" | "Cloud Container";
  status: "Online" | "Syncing" | "Offline";
  cpuUsage: number;
  memoryUsage: number;
  activeTaskCount: number;
  lastSync: string;
  location?: string;
}

export interface EmotionScanResult {
  emotion: string;
  confidence: number;
  metrics: {
    stressLevel: number;
    attentiveness: number;
    energyLevel: number;
    microExpressions: string[];
  };
  suggestedTone: string;
  actionRecommendation: string;
  timestamp: string;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "assistant" | "system";
  text: string;
  timestamp: string;
  isVoice?: boolean;
  emotionContext?: string;
  codeSnippet?: string;
}
